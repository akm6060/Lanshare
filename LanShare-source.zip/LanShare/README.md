# LanShare 1.4.0

Send files, folders and text between Android devices on the same Wi-Fi (or hotspot).
No internet, no account, no compression: files arrive byte-for-byte identical, with
their original dates.

## Updating from 1.0 (iPad)
1. In your GitHub repo: **Add file → Upload files** → upload the new `LanShare-source.zip`
   (same name, it replaces the old one) → Commit.
2. **Actions** tab → wait for the green tick → **Artifacts → LanShare-apk**.
3. Install `LanShare.apk` on **all** devices (it installs over 1.0; history is kept).
   Version 1.1 can't talk to 1.0, so update every device.

## What's new in 1.4.0 — prescriptions sent back to the main tablet
For the chain: main tablet (auto-send) → store + second tablet; the second tablet (or the store)
sends prescriptions back BY HAND, e.g. with test results filled in, for the doctor to complete.

Main tablet settings:
1. Settings → receive folder = `styluslabs/write`, "If a file already exists" = **Replace**
   (send back the file itself, not a folder, so it lands directly in the Write folder).
2. Auto-send: watch the Write folder and the backup folder; send to the store and the second tablet.
3. Daily move: Write folder → backup folder.

What happens:
- A file sent back replaces the same-named file in the Write folder (or is added there, if the
  original is in the backup folder). Its arrival sends nothing ("received from …; it will be sent
  on only after it is edited" in Recent activity).
- When the doctor completes it and presses back, it is auto-sent to the store and second tablet.
- Daily move: a completed returned copy **replaces** its original in the backup folder. Any other
  same-name clash is still left in place with a notification.
- Auto-send may now watch LanShare's own receive folder (received files never bounce back).

Opening from History: Write documents now open **directly in Write** (Write 2.0 could not open the
link it was given: "Error opening document"). Edits made there are auto-sent as usual.
Long-press an entry → **Open with…** to choose another app, e.g. a browser.

Only the main tablet needs 1.4.0; the second tablet and the store can stay as they are.

## What's new in 1.3.3
- Removing a folder from "Folders to watch" keeps its fingerprints. Adding the same folder back
  is instant: only files that changed in the meantime are read again (and they are not sent —
  everything in a folder when it is added counts as sent). Records of files deleted meanwhile are
  cleaned up every few hours.

## What's new in 1.3.2
- Fix: a file name that exists in two watched folders (e.g. "z tests.html" in both the Write
  folder and the backup folder) was sent again every 3 minutes, alternating between the two copies.
  Auto-send now remembers what it sent per file location, so only a real change is sent.
- On the first start after updating, everything already in the folders counts as sent.

## What's new in 1.3.1
- Auto-send stays quick with very large folders (thousands of prescriptions). Files already in a
  folder are noted by size and date only (seconds instead of many minutes); their content is read
  slowly in the background without holding up sending.
- New prescriptions are handled first, and a big backlog never blocks them.
- **Recent activity** list on the Auto-send screen: "change seen", "sending", "sent",
  "not reachable", or the exact problem, so it's clear what auto-send is doing.

## What's new in 1.3.0 — Auto-send & daily move
Replaces the auto-clicker for prescriptions. Menu ⋮ → **Auto-send & daily move**
(also at the top of Settings).

**Auto-send** — set up once on the clinic tablet:
1. Switch on **Send files automatically after they are saved**.
2. **Add folder** → choose the Write folder, then **Add folder** again → the backup folder.
3. Under **Send to**, tick the store device.
That's it: write the prescription, press back — it reaches the store a few seconds later
("Sent “name” to …" appears briefly). Editing an old prescription from the backup folder works the same way.
- Only real changes count: opening or scrolling an old Write prescription does not send it.
- Files already in the folders when you switch it on are not sent.
- A file moved from the Write folder to the backup folder is not sent again.
- If the store device is off or away, files wait and go as soon as it's back
  (a notification tells you if it's away for more than a minute).
- At the store, files go into `Download/LanShare/Prescriptions` (folder name changeable),
  and an edited prescription **replaces** the earlier copy.
- File types: `html` by default (Write documents). Wait after saving: 3 seconds.

**Daily move** — Write folder → backup folder:
1. Switch on **Move the previous days' files every day**.
2. **Move from** = Write folder, **Move to** = backup folder.
- Files last changed before today are moved shortly after midnight (or as soon as LanShare runs,
  if the tablet was off). A name that already exists in the backup folder is left in place and you get
  a notification. Every move is listed in the **Move log**.
- **Close day now** moves everything immediately (close the open prescription in Write first).

**Open files from History** — tap an entry in History to open the file (a prescription opens in
Write or your browser; several files → pick one). Long-press for the details (time, size, speed).
A prescription that the daily move has put in the backup folder is still found.
Works for transfers made with 1.3 or newer.

Install 1.3.0 on **both** the tablet and the store device (the store needs it for "replace").
Auto-send and daily move run inside LanShare's background service, so keep
"Allow running in background" on, and don't use "Stop LanShare" on the tablet.

## What's new in 1.2.1
- Offline devices are no longer listed; they come back by themselves when online.
- A silent device is removed from the list after 30 seconds.
- Now installs on Android 6 and 7 too (was Android 8+).
- Fix: a folder whose name matches an existing file is saved as "Name (1)"; shared folders are sent with their files.

## What's new in 1.2
- **Steady device list.** Devices no longer blink out: LanShare now also contacts known
  devices directly and double-checks with a quick ping before showing one as away.
  The list stays in alphabetical order. A device with its screen off shows an **amber dot**
  and files are still sent to it (the connection wakes it).
- **Works with the screen off.** LanShare keeps Wi-Fi and itself awake in the background
  (Settings → "Stay reachable when the screen is off"), starts by itself after a phone
  restart, and the home screen asks for background permission if it's missing.

## What's new in 1.1
- **No pairing.** Every device with LanShare on your home network can send and receive.
- **Send to several devices at once.** Tick devices on the home screen, then tap
  Files / Folder / Text / Clipboard at the bottom. Your ticks are remembered.
  Long-press a device to send to just that one.
- **Folders without the "Allow access?" question** (LanShare's own folder browser;
  it opens where you last sent from).
- **Sound when something arrives**, even in the background. Choose or turn off in Settings.
- **Cleaner home screen.** Device name and IP are in the top bar; full details in Settings.

## Using it
- Received files go to `Download/LanShare` (changeable in Settings), folder structure kept.
- Duplicate names: Overwrite (default), Keep both, or Skip — Settings.
- Received text is copied to the clipboard automatically (can be turned off).
- From any app: **Share → LanShare – send to device → Send** (ticks are pre-filled).
- If a transfer breaks, tap **Retry** in History: it continues where it stopped.

## Notes
- Settings → **Allow running in background** on every device (Xiaomi, Vivo, Oppo, Realme, Samsung…).
- The arrival sound follows the phone's notification volume, so it's silent when the phone is on silent.
- Ports: TCP 47820, UDP 47821. Empty folders are not copied.

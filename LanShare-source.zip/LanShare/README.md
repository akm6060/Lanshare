# LanShare

Send files, folders and text between Android devices on the same Wi-Fi (or hotspot).
No internet, no account, no compression: files arrive byte-for-byte identical, with
their original dates.

## Build from an iPad (GitHub Actions)
1. Create a new GitHub repository (e.g. `lanshare`).
2. **Add file → Upload files** → upload `LanShare-source.zip` → Commit.
3. **Add file → Create new file**, name it `.github/workflows/build.yml`,
   paste the contents of `build.yml` → Commit.
4. Open the **Actions** tab → wait for the green tick (about 4–6 min).
5. Open the run → **Artifacts → LanShare-apk** → download, unzip, install `LanShare.apk`
   on every device.

Every build is signed with the same key, so new versions install as updates.

## First use (on each device)
1. Open LanShare → allow notifications and **file access**.
2. Settings → **Allow running in background** (important on Xiaomi, Vivo, Oppo, Realme, Samsung).
3. Both devices on the same Wi-Fi → each appears under "Devices on this network".
4. Tap **Pair** on one device; check the 6-digit code on the other and tap **Accept**.
   Pairing is needed only once.

## Using it
- Tap a paired device → Send files / Send a folder / Send text / Send my clipboard.
- From any app: **Share → LanShare – send to device**.
- Received files go to `Download/LanShare` (changeable in Settings), with folder structure kept.
- Duplicate names: Overwrite (default), Keep both, or Skip — set in Settings.
- Received text is copied to the clipboard automatically (can be turned off).
- If a transfer breaks, tap **Retry** in History: it continues from where it stopped.

## Notes
- Ports used: TCP 47820, UDP 47821. Some guest/office Wi-Fi networks block
  device-to-device traffic ("AP/client isolation"); use a phone hotspot instead.
- Pairing is protected by a shared key (each connection is verified), but file data
  itself is not encrypted, so use it on networks you trust.
- Empty folders are not copied.

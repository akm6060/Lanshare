# LanShare 1.2

Send files, folders and text between Android devices on the same Wi-Fi (or hotspot).
No internet, no account, no compression: files arrive byte-for-byte identical, with
their original dates.

## Updating from 1.0 (iPad)
1. In your GitHub repo: **Add file → Upload files** → upload the new `LanShare-source.zip`
   (same name, it replaces the old one) → Commit.
2. **Actions** tab → wait for the green tick → **Artifacts → LanShare-apk**.
3. Install `LanShare.apk` on **all** devices (it installs over 1.0; history is kept).
   Version 1.1 can't talk to 1.0, so update every device.

## What's new in 1.2
- **Steady device list.** Devices no longer blink out: LanShare now also contacts known
  devices directly and double-checks with a quick ping before showing one as away.
  The list stays in alphabetical order. A device with its screen off shows an **amber dot**
  and files are still sent to it (the connection wakes it).
- **Works with the screen off.** LanShare keeps Wi-Fi and itself awake in the background
  (Settings → "Stay reachable when the screen is off"), starts by itself after a phone
  restart, and the home screen asks for background permission if it's missing.

## What's new in 1.1
- **No pairing.** Every device with LanShare on your home network can send and receive.
- **Send to several devices at once.** Tick devices on the home screen, then tap
  Files / Folder / Text / Clipboard at the bottom. Your ticks are remembered.
  Long-press a device to send to just that one.
- **Folders without the "Allow access?" question** (LanShare's own folder browser;
  it opens where you last sent from).
- **Sound when something arrives**, even in the background. Choose or turn off in Settings.
- **Cleaner home screen.** Device name and IP are in the top bar; full details in Settings.

## Using it
- Received files go to `Download/LanShare` (changeable in Settings), folder structure kept.
- Duplicate names: Overwrite (default), Keep both, or Skip — Settings.
- Received text is copied to the clipboard automatically (can be turned off).
- From any app: **Share → LanShare – send to device → Send** (ticks are pre-filled).
- If a transfer breaks, tap **Retry** in History: it continues where it stopped.

## Notes
- Settings → **Allow running in background** on every device (Xiaomi, Vivo, Oppo, Realme, Samsung…).
- The arrival sound follows the phone's notification volume, so it's silent when the phone is on silent.
- Ports: TCP 47820, UDP 47821. Empty folders are not copied.

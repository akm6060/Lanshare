package com.lanshare.app

import android.content.Context
import android.net.wifi.WifiManager
import android.os.PowerManager
import android.util.Log
import java.util.concurrent.Executors

/**
 * Background thread pool. While anything is running, Wi-Fi is kept in
 * high-performance mode and the CPU stays awake, so transfers don't slow
 * down or stall when the screen turns off.
 */
object Work {
    private val pool = Executors.newCachedThreadPool()
    private var busy = 0
    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var standbyWifi: WifiManager.WifiLock? = null
    private var standbyWake: PowerManager.WakeLock? = null

    @Suppress("DEPRECATION")
    fun init(ctx: Context) {
        val app = ctx.applicationContext
        try {
            val wm = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "LanShare:wifi")
            wifiLock?.setReferenceCounted(false)
            standbyWifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "LanShare:standby-wifi")
            standbyWifi?.setReferenceCounted(false)
        } catch (e: Exception) { }
        try {
            val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LanShare:transfer")
            wakeLock?.setReferenceCounted(false)
            standbyWake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LanShare:standby")
            standbyWake?.setReferenceCounted(false)
        } catch (e: Exception) { }
    }

    /**
     * While on, the phone keeps announcing itself and answering with the screen off.
     * Costs some battery; can be switched off in Settings.
     */
    @Synchronized
    fun setStandby(on: Boolean) {
        try {
            if (on) {
                if (standbyWake?.isHeld != true) standbyWake?.acquire()
                if (standbyWifi?.isHeld != true) standbyWifi?.acquire()
            } else {
                if (standbyWake?.isHeld == true) standbyWake?.release()
                if (standbyWifi?.isHeld == true) standbyWifi?.release()
            }
        } catch (e: Exception) { }
    }

    fun run(block: () -> Unit) {
        pool.execute {
            begin()
            try {
                block()
            } catch (t: Throwable) {
                Log.e("LanShare", "Background task failed", t)
            } finally {
                end()
            }
        }
    }

    @Synchronized
    private fun begin() {
        busy++
        if (busy == 1) {
            try { wifiLock?.acquire() } catch (e: Exception) { }
            try { wakeLock?.acquire(6L * 60 * 60 * 1000) } catch (e: Exception) { }
        }
    }

    @Synchronized
    private fun end() {
        busy--
        if (busy <= 0) {
            busy = 0
            try { if (wifiLock?.isHeld == true) wifiLock?.release() } catch (e: Exception) { }
            try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (e: Exception) { }
        }
    }
}

package com.lanshare.app

import android.content.Context
import org.json.JSONArray
import java.io.File

/** Paired devices + transfer history, saved as small JSON files in app storage. */
object Store {
    private const val MAX_HISTORY = 300
    private lateinit var dir: File
    private val paired = LinkedHashMap<String, PairedDevice>()
    private val history = ArrayList<HistoryEntry>()

    @Volatile var historyVersion = 0
        private set

    @Synchronized
    fun init(ctx: Context) {
        dir = ctx.filesDir
        try {
            val a = JSONArray(File(dir, "paired.json").readText())
            for (i in 0 until a.length()) {
                val d = PairedDevice.fromJson(a.getJSONObject(i))
                paired[d.id] = d
            }
        } catch (e: Exception) { }
        try {
            val a = JSONArray(File(dir, "history.json").readText())
            for (i in 0 until a.length()) {
                val h = HistoryEntry.fromJson(a.getJSONObject(i))
                if (h.status == HistoryEntry.ACTIVE) {
                    h.status = HistoryEntry.FAILED
                    h.error = "Interrupted (app was closed)"
                }
                history.add(h)
            }
        } catch (e: Exception) { }
    }

    private fun write(name: String, content: String) {
        try {
            val target = File(dir, name)
            val tmp = File(dir, "$name.tmp")
            tmp.writeText(content)
            if (!tmp.renameTo(target)) {
                target.writeText(content)
                tmp.delete()
            }
        } catch (e: Exception) { }
    }

    private fun savePaired() {
        val a = JSONArray()
        for (d in paired.values) a.put(d.toJson())
        write("paired.json", a.toString())
    }

    private fun saveHistory() {
        val a = JSONArray()
        for (h in history) a.put(h.toJson())
        write("history.json", a.toString())
        historyVersion++
    }

    @Synchronized fun pairedList(): List<PairedDevice> = paired.values.toList()

    @Synchronized fun getPaired(id: String): PairedDevice? = paired[id]

    @Synchronized
    fun addPaired(d: PairedDevice) {
        paired[d.id] = d
        savePaired()
    }

    @Synchronized
    fun removePaired(id: String) {
        paired.remove(id)
        savePaired()
    }

    @Synchronized
    fun updatePairedName(id: String, name: String) {
        val d = paired[id] ?: return
        if (name.isNotBlank() && d.name != name) {
            paired[id] = d.copy(name = name)
            savePaired()
        }
    }

    @Synchronized fun historyList(): List<HistoryEntry> = history.toList()

    @Synchronized fun findHistory(id: String): HistoryEntry? = history.firstOrNull { it.id == id }

    /** Insert or move an entry to the top and save. */
    @Synchronized
    fun putHistory(h: HistoryEntry) {
        history.removeAll { it.id == h.id }
        history.add(0, h)
        while (history.size > MAX_HISTORY) history.removeAt(history.size - 1)
        saveHistory()
    }

    @Synchronized
    fun clearHistory() {
        history.removeAll { it.status != HistoryEntry.ACTIVE }
        saveHistory()
    }
}

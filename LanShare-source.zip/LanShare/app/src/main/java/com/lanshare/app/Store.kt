package com.lanshare.app

import android.content.Context
import org.json.JSONArray
import java.io.File

/** Known devices + transfer history, saved as small JSON files in app storage. */
object Store {
    private const val MAX_HISTORY = 300
    private lateinit var dir: File
    private val known = LinkedHashMap<String, KnownDevice>()
    private val history = ArrayList<HistoryEntry>()

    @Volatile var historyVersion = 0
        private set

    @Synchronized
    fun init(ctx: Context) {
        dir = ctx.filesDir
        try {
            val a = JSONArray(File(dir, "paired.json").readText())
            for (i in 0 until a.length()) {
                val d = KnownDevice.fromJson(a.getJSONObject(i))
                known[d.id] = d
            }
        } catch (e: Exception) { }
        try {
            val a = JSONArray(File(dir, "history.json").readText())
            for (i in 0 until a.length()) {
                val h = HistoryEntry.fromJson(a.getJSONObject(i))
                if (h.status == HistoryEntry.ACTIVE) {
                    h.status = HistoryEntry.FAILED
                    h.error = "Interrupted (app was closed)"
                }
                history.add(h)
            }
        } catch (e: Exception) { }
    }

    private fun write(name: String, content: String) {
        try {
            val target = File(dir, name)
            val tmp = File(dir, "$name.tmp")
            tmp.writeText(content)
            if (!tmp.renameTo(target)) {
                target.writeText(content)
                tmp.delete()
            }
        } catch (e: Exception) { }
    }

    private fun saveKnown() {
        val a = JSONArray()
        for (d in known.values) a.put(d.toJson())
        write("paired.json", a.toString())
    }

    private fun saveHistory() {
        val a = JSONArray()
        for (h in history) a.put(h.toJson())
        write("history.json", a.toString())
        historyVersion++
    }

    @Synchronized fun knownList(): List<KnownDevice> = known.values.toList()

    @Synchronized fun getKnown(id: String): KnownDevice? = known[id]

    /** Remember a device seen on the network (adds it, or updates its name). */
    @Synchronized
    fun remember(id: String, name: String) {
        if (id.isEmpty()) return
        val d = known[id]
        if (d != null && (d.name == name || name.isBlank())) return
        known[id] = KnownDevice(id, if (name.isBlank()) "Device" else name)
        saveKnown()
    }

    @Synchronized
    fun forget(id: String) {
        known.remove(id)
        saveKnown()
    }

    @Synchronized fun historyList(): List<HistoryEntry> = history.toList()

    @Synchronized fun findHistory(id: String): HistoryEntry? = history.firstOrNull { it.id == id }

    /** Insert or move an entry to the top and save. */
    @Synchronized
    fun putHistory(h: HistoryEntry) {
        history.removeAll { it.id == h.id }
        history.add(0, h)
        while (history.size > MAX_HISTORY) history.removeAt(history.size - 1)
        saveHistory()
    }

    @Synchronized
    fun clearHistory() {
        history.removeAll { it.status != HistoryEntry.ACTIVE }
        saveHistory()
    }
}

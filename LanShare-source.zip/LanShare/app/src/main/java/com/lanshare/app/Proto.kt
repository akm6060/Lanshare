package com.lanshare.app

import android.util.Base64
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** An error that should NOT be retried automatically (e.g. not paired, rejected). */
class FatalTransferException(msg: String) : IOException(msg)

/**
 * Wire protocol.
 * Control messages = 4-byte length + UTF-8 JSON. File bytes are sent raw, uncompressed,
 * straight after the "accept" message, one file after another.
 */
object Proto {
    const val TCP_PORT = 47820
    const val UDP_PORT = 47821
    const val VERSION = 1
    const val BUF = 256 * 1024
    private const val SOCK_BUF = 1 shl 20
    private val rnd = SecureRandom()

    fun writeMsg(out: DataOutputStream, o: JSONObject) {
        val b = o.toString().toByteArray(Charsets.UTF_8)
        out.writeInt(b.size)
        out.write(b)
        out.flush()
    }

    fun readMsg(inp: DataInputStream): JSONObject {
        val n = inp.readInt()
        if (n < 0 || n > 64 * 1024 * 1024) throw IOException("Bad message from other device")
        val b = ByteArray(n)
        inp.readFully(b)
        return JSONObject(String(b, Charsets.UTF_8))
    }

    fun tune(s: Socket) {
        try { s.tcpNoDelay = true } catch (e: Exception) { }
        try { s.sendBufferSize = SOCK_BUF } catch (e: Exception) { }
        try { s.receiveBufferSize = SOCK_BUF } catch (e: Exception) { }
    }

    fun connect(ip: String, port: Int): Socket {
        val s = Socket()
        tune(s)
        s.connect(InetSocketAddress(ip, port), 6000)
        s.soTimeout = 30_000
        return s
    }

    fun randomB64(bytes: Int): String {
        val b = ByteArray(bytes)
        rnd.nextBytes(b)
        return Base64.encodeToString(b, Base64.NO_WRAP)
    }

    fun hmac(secretB64: String, msg: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(Base64.decode(secretB64, Base64.NO_WRAP), "HmacSHA256"))
        return Base64.encodeToString(mac.doFinal(msg.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
    }

    fun macEquals(a: String, b: String): Boolean =
        MessageDigest.isEqual(a.toByteArray(Charsets.UTF_8), b.toByteArray(Charsets.UTF_8))

    fun sha1Hex(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    fun pairCode(): String = (100000 + rnd.nextInt(900000)).toString()
}

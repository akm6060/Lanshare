package com.lanshare.app

import android.content.Context
import java.net.InetSocketAddress
import java.net.ServerSocket
import kotlin.concurrent.thread

/** Listens for incoming connections (pairing, files, text). */
class Server(private val ctx: Context) {
    @Volatile private var running = false
    private var ss: ServerSocket? = null

    var port: Int = Proto.TCP_PORT
        private set

    private fun open(p: Int): ServerSocket {
        val s = ServerSocket()
        s.reuseAddress = true
        s.receiveBufferSize = 1 shl 20
        s.bind(InetSocketAddress(p))
        return s
    }

    fun start() {
        running = true
        val s = try { open(Proto.TCP_PORT) } catch (e: Exception) { open(0) }
        ss = s
        port = s.localPort
        thread(name = "lanshare-server", isDaemon = true) {
            while (running) {
                try {
                    val c = s.accept()
                    Work.run { Receiver(ctx, c).handle() }
                } catch (e: Exception) {
                    if (!running) break
                }
            }
        }
    }

    fun stop() {
        running = false
        try { ss?.close() } catch (e: Exception) { }
    }
}

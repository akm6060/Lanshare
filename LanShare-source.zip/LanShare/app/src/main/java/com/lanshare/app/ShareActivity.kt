package com.lanshare.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.IntentCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** Appears in other apps' Share menu ("LanShare – send to device"). */
class ShareActivity : AppCompatActivity() {
    private var items: List<SendItem>? = null
    private var text: String? = null
    private var transferId: String? = null
    private var finishing = false

    private lateinit var adapter: DeviceAdapter
    private lateinit var txtHeader: TextView
    private lateinit var txtEmpty: TextView
    private lateinit var list: RecyclerView
    private lateinit var progressBox: View

    private val hubListener: () -> Unit = { render() }
    private val ticker = object : Runnable {
        override fun run() {
            render()
            Hub.main.postDelayed(this, 1500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_share)
        TransferService.start(this)

        txtHeader = findViewById(R.id.txtHeader)
        txtEmpty = findViewById(R.id.txtEmpty)
        list = findViewById(R.id.listTargets)
        progressBox = findViewById(R.id.progressBox)

        adapter = DeviceAdapter { row -> onPick(row) }
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        findViewById<Button>(R.id.btnClose).setOnClickListener { finish() }

        transferId = savedInstanceState?.getString("tid")
        parseIntent(intent)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("tid", transferId)
    }

    override fun onResume() {
        super.onResume()
        Hub.addListener(hubListener)
        Hub.main.post(ticker)
    }

    override fun onPause() {
        Hub.removeListener(hubListener)
        Hub.main.removeCallbacks(ticker)
        super.onPause()
    }

    private fun parseIntent(i: Intent) {
        val uris = ArrayList<Uri>()
        if (i.action == Intent.ACTION_SEND_MULTIPLE) {
            val l = IntentCompat.getParcelableArrayListExtra(i, Intent.EXTRA_STREAM, Uri::class.java)
            if (l != null) uris.addAll(l)
        } else if (i.action == Intent.ACTION_SEND) {
            val u = IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java)
            if (u != null) uris.add(u)
        }

        if (uris.isEmpty()) {
            val t = i.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
            if (t.isNullOrEmpty()) {
                toast("Nothing to send")
                finish()
                return
            }
            text = t
            txtHeader.text = "Send text to…"
            return
        }

        for (u in uris) {
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) { }
        }
        txtHeader.text = "Reading ${uris.size} item(s)…"
        val app = applicationContext
        Work.run {
            val r = try {
                Util.ensureSized(app, uris.map { Util.describeUri(app, it) })
            } catch (e: Exception) { emptyList() }
            Hub.main.post {
                items = r
                if (transferId == null) {
                    txtHeader.text = if (r.isEmpty()) "Couldn't read the shared files"
                    else "Send ${r.size} file(s), ${Util.formatBytes(r.sumOf { it.size })}, to…"
                }
                render()
            }
        }
    }

    private fun render() {
        if (isDestroyed) return
        val tid = transferId
        if (tid == null) {
            val rows = Hub.deviceRows().filter { it.paired && it.peer != null }
            adapter.submit(rows)
            list.visibility = View.VISIBLE
            txtEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
            progressBox.visibility = View.GONE
            return
        }
        list.visibility = View.GONE
        txtEmpty.visibility = View.GONE
        progressBox.visibility = View.VISIBLE
        val t = Hub.active[tid]
        if (t != null) {
            TransferViews.bind(progressBox, t)
            return
        }
        val h = Store.findHistory(tid) ?: return
        when (h.status) {
            HistoryEntry.DONE -> {
                txtHeader.text = "✓ Sent to ${h.deviceName}"
                progressBox.visibility = View.GONE
                if (!finishing) {
                    finishing = true
                    Hub.main.postDelayed({ if (!isFinishing) finish() }, 1200)
                }
            }
            HistoryEntry.FAILED -> {
                txtHeader.text = "✗ ${h.error ?: "Failed"}\nYou can tap Retry in LanShare's history."
                progressBox.visibility = View.GONE
            }
            HistoryEntry.CANCELLED -> {
                txtHeader.text = "Cancelled"
                progressBox.visibility = View.GONE
            }
        }
    }

    private fun onPick(row: DeviceRow) {
        val app = applicationContext
        val t = text
        if (t != null) {
            Work.run { Sender.sendText(app, row.id, t) }
            finish()
            return
        }
        val its = items
        if (its == null) {
            toast("Still reading files, one moment…")
            return
        }
        if (its.isEmpty()) return
        val id = Sender.newId()
        transferId = id
        val title = if (its.size == 1) its[0].relPath else "${its.size} files"
        Work.run { Sender.sendFiles(app, row.id, its, title, id) }
        txtHeader.text = "Sending to ${row.name}… (you can switch to other apps)"
        render()
    }
}

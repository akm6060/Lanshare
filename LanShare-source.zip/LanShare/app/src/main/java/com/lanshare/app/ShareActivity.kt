package com.lanshare.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.IntentCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/**
 * Appears in other apps' Share menu ("LanShare – send to device").
 * Devices ticked last time are already ticked, so it's usually just: Share → LanShare → Send.
 */
class ShareActivity : AppCompatActivity() {
    private var items: List<SendItem>? = null
    private var text: String? = null
    private var transferIds: List<String> = emptyList()
    private var finishing = false
    private val transferViews = HashMap<String, View>()

    private lateinit var adapter: DeviceAdapter
    private lateinit var txtHeader: TextView
    private lateinit var txtEmpty: TextView
    private lateinit var list: RecyclerView
    private lateinit var scrollTransfers: View
    private lateinit var boxTransfers: LinearLayout
    private lateinit var btnSend: Button

    private val hubListener: () -> Unit = { render() }
    private val ticker = object : Runnable {
        override fun run() {
            render()
            Hub.main.postDelayed(this, 1500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_share)
        TransferService.start(this)

        txtHeader = findViewById(R.id.txtHeader)
        txtEmpty = findViewById(R.id.txtEmpty)
        list = findViewById(R.id.listTargets)
        scrollTransfers = findViewById(R.id.scrollTransfers)
        boxTransfers = findViewById(R.id.boxTransfers)
        btnSend = findViewById(R.id.btnSend)

        adapter = DeviceAdapter(
            isSelected = { id -> Hub.isSelected(this, id) },
            onTap = { row -> Hub.toggle(this, row.id); render() },
            onLongPress = { row -> Hub.toggle(this, row.id); render() }
        )
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        findViewById<Button>(R.id.btnClose).setOnClickListener { finish() }
        btnSend.setOnClickListener { onSend() }

        transferIds = savedInstanceState?.getStringArray("tids")?.toList() ?: emptyList()
        parseIntent(intent)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putStringArray("tids", transferIds.toTypedArray())
    }

    override fun onResume() {
        super.onResume()
        Hub.addListener(hubListener)
        Hub.main.post(ticker)
    }

    override fun onPause() {
        Hub.removeListener(hubListener)
        Hub.main.removeCallbacks(ticker)
        super.onPause()
    }

    private fun parseIntent(i: Intent) {
        val uris = ArrayList<Uri>()
        if (i.action == Intent.ACTION_SEND_MULTIPLE) {
            val l = IntentCompat.getParcelableArrayListExtra(i, Intent.EXTRA_STREAM, Uri::class.java)
            if (l != null) uris.addAll(l)
        } else if (i.action == Intent.ACTION_SEND) {
            val u = IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java)
            if (u != null) uris.add(u)
        }

        if (uris.isEmpty()) {
            val t = i.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
            if (t.isNullOrEmpty()) {
                toast("Nothing to send")
                finish()
                return
            }
            text = t
            txtHeader.text = "Send text to:"
            return
        }

        for (u in uris) {
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) { }
        }
        txtHeader.text = "Reading ${uris.size} item(s)…"
        val app = applicationContext
        Work.run {
            val r = try {
                Util.ensureSized(app, uris.map { Util.describeUri(app, it) })
            } catch (e: Exception) { emptyList() }
            Hub.main.post {
                items = r
                if (transferIds.isEmpty()) {
                    txtHeader.text = if (r.isEmpty()) "Couldn't read the shared files"
                    else "Send ${r.size} file(s), ${Util.formatBytes(r.sumOf { it.size })}, to:"
                }
                render()
            }
        }
    }

    private fun render() {
        if (isDestroyed) return
        if (transferIds.isEmpty()) {
            val rows = Hub.deviceRows()
            adapter.submit(rows)
            list.visibility = View.VISIBLE
            scrollTransfers.visibility = View.GONE
            txtEmpty.visibility = if (rows.none { it.peer != null }) View.VISIBLE else View.GONE
            val n = Hub.selectedOnline(this).size
            btnSend.visibility = View.VISIBLE
            btnSend.isEnabled = n > 0
            btnSend.text = if (n <= 1) "Send" else "Send to $n"
            return
        }

        list.visibility = View.GONE
        txtEmpty.visibility = View.GONE
        btnSend.visibility = View.GONE
        scrollTransfers.visibility = View.VISIBLE

        var running = 0
        for (id in transferIds) {
            val t = Hub.active[id]
            val existing = transferViews[id]
            if (t != null) {
                running++
                val v = existing ?: LayoutInflater.from(this).inflate(R.layout.item_transfer, boxTransfers, false).also {
                    boxTransfers.addView(it)
                    transferViews[id] = it
                }
                TransferViews.bind(v, t)
            } else if (existing != null) {
                boxTransfers.removeView(existing)
                transferViews.remove(id)
            }
        }
        if (running > 0) return

        val results = transferIds.mapNotNull { Store.findHistory(it) }
        if (results.size < transferIds.size || results.any { it.status == HistoryEntry.ACTIVE }) return
        val ok = results.filter { it.status == HistoryEntry.DONE }
        val bad = results.filter { it.status != HistoryEntry.DONE }
        if (bad.isEmpty()) {
            txtHeader.text = "✓ Sent to " + ok.joinToString(", ") { it.deviceName }
            if (!finishing) {
                finishing = true
                Hub.main.postDelayed({ if (!isFinishing) finish() }, 1200)
            }
        } else {
            val sb = StringBuilder()
            if (ok.isNotEmpty()) sb.append("✓ Sent to ").append(ok.joinToString(", ") { it.deviceName }).append("\n")
            for (b in bad) sb.append("✗ ").append(b.deviceName).append(": ").append(b.error ?: "Failed").append("\n")
            sb.append("You can tap Retry in LanShare's history.")
            txtHeader.text = sb.toString()
        }
    }

    private fun onSend() {
        val ids = Hub.selectedOnline(this).map { it.id }
        if (ids.isEmpty()) {
            toast("Tick at least one online device")
            return
        }
        val app = applicationContext
        val t = text
        if (t != null) {
            Sender.sendTextToMany(app, ids, t)
            finish()
            return
        }
        val its = items
        if (its == null) {
            toast("Still reading files, one moment…")
            return
        }
        if (its.isEmpty()) return
        val title = if (its.size == 1) its[0].relPath else "${its.size} files"
        val newIds = ArrayList<String>()
        for (deviceId in ids) {
            val tid = Sender.newId()
            newIds.add(tid)
            Work.run { Sender.sendFiles(app, deviceId, its, title, tid) }
        }
        transferIds = newIds
        txtHeader.text = "Sending to ${ids.size} device(s)… (you can switch to other apps)"
        render()
    }
}

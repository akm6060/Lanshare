package com.lanshare.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.net.Socket
import java.util.concurrent.atomic.AtomicReference

class MainActivity : AppCompatActivity() {
    private lateinit var deviceAdapter: DeviceAdapter
    private lateinit var historyAdapter: HistoryAdapter
    private lateinit var boxTransfers: LinearLayout
    private lateinit var headerTransfers: TextView
    private lateinit var txtNoDevices: TextView
    private lateinit var txtNoHistory: TextView
    private lateinit var txtMyName: TextView
    private lateinit var txtMyInfo: TextView
    private lateinit var cardWarn: View
    private lateinit var txtWarn: TextView
    private lateinit var btnWarn: Button

    private var targetId: String? = null
    private var shownPair: PendingPair? = null
    private var lastHistoryVersion = -1
    private val transferViews = HashMap<String, View>()

    private val hubListener: () -> Unit = { refresh() }
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            Hub.main.postDelayed(this, 2000)
        }
    }

    private val pickFiles =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> onFilesPicked(uris) }
    private val pickFolder =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) onFolderPicked(uri) }
    private val askPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById<MaterialToolbar>(R.id.toolbar))
        targetId = savedInstanceState?.getString("target")

        boxTransfers = findViewById(R.id.boxTransfers)
        headerTransfers = findViewById(R.id.headerTransfers)
        txtNoDevices = findViewById(R.id.txtNoDevices)
        txtNoHistory = findViewById(R.id.txtNoHistory)
        txtMyName = findViewById(R.id.txtMyName)
        txtMyInfo = findViewById(R.id.txtMyInfo)
        cardWarn = findViewById(R.id.cardWarn)
        txtWarn = findViewById(R.id.txtWarn)
        btnWarn = findViewById(R.id.btnWarn)

        deviceAdapter = DeviceAdapter { row -> onDeviceClicked(row) }
        findViewById<RecyclerView>(R.id.listDevices).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = deviceAdapter
            isNestedScrollingEnabled = false
        }

        historyAdapter = HistoryAdapter(
            onClick = { h -> onHistoryClicked(h) },
            onRetry = { h ->
                val app = applicationContext
                Work.run { Sender.retry(app, h) }
            }
        )
        findViewById<RecyclerView>(R.id.listHistory).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = historyAdapter
            isNestedScrollingEnabled = false
        }

        findViewById<Button>(R.id.btnClearHistory).setOnClickListener {
            Store.clearHistory()
            refresh()
        }

        TransferService.start(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("target", targetId)
    }

    override fun onResume() {
        super.onResume()
        TransferService.start(this)
        Hub.addListener(hubListener)
        lastHistoryVersion = -1
        Hub.main.post(ticker)
    }

    override fun onPause() {
        Hub.removeListener(hubListener)
        Hub.main.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_refresh -> {
                Hub.discovered.clear()
                Discovery.current?.announceAsync()
                refresh()
                toast("Searching for devices…")
            }
            R.id.menu_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            R.id.menu_exit -> {
                TransferService.stop(this)
                finishAffinity()
            }
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    // ---------------- screen ----------------

    private fun refresh() {
        if (isDestroyed) return
        txtMyName.text = "This device: " + Prefs.deviceName(this)
        val ips = Util.localIps()
        val net = if (ips.isEmpty()) "Not connected to Wi-Fi / hotspot" else "IP " + ips.joinToString(", ")
        txtMyInfo.text = net + "\nIncoming files → " + Prefs.receiveDir(this).absolutePath

        if (!Util.hasStorageAccess(this)) {
            cardWarn.visibility = View.VISIBLE
            txtWarn.text = "Allow file access so incoming files can be saved automatically to your LanShare folder."
            btnWarn.setOnClickListener {
                Util.requestStorageAccess(this) { askPermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE) }
            }
        } else {
            cardWarn.visibility = View.GONE
        }

        val rows = Hub.deviceRows()
        deviceAdapter.submit(rows)
        txtNoDevices.visibility = if (rows.any { it.peer != null }) View.GONE else View.VISIBLE

        renderTransfers()

        if (Store.historyVersion != lastHistoryVersion) {
            lastHistoryVersion = Store.historyVersion
            val hist = Store.historyList()
            historyAdapter.submit(hist)
            txtNoHistory.visibility = if (hist.isEmpty()) View.VISIBLE else View.GONE
        }

        checkPendingPair()
    }

    private fun renderTransfers() {
        val list = Hub.active.values.sortedBy { it.id }
        headerTransfers.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        val ids = list.map { it.id }.toSet()
        val iter = transferViews.entries.iterator()
        while (iter.hasNext()) {
            val e = iter.next()
            if (e.key !in ids) {
                boxTransfers.removeView(e.value)
                iter.remove()
            }
        }
        for (t in list) {
            val v = transferViews.getOrPut(t.id) {
                val nv = LayoutInflater.from(this).inflate(R.layout.item_transfer, boxTransfers, false)
                boxTransfers.addView(nv)
                nv
            }
            TransferViews.bind(v, t)
        }
    }

    // ---------------- devices ----------------

    private fun onDeviceClicked(row: DeviceRow) {
        val peer = row.peer
        if (!row.paired) {
            if (peer != null) startPair(peer)
            return
        }
        if (peer == null) {
            MaterialAlertDialogBuilder(this)
                .setTitle(row.name)
                .setMessage("Offline. Open LanShare on that device and connect it to the same Wi-Fi.")
                .setPositiveButton("OK", null)
                .setNeutralButton("Unpair") { _, _ -> confirmUnpair(row) }
                .show()
            return
        }
        val options = arrayOf("Send files", "Send a folder", "Send text", "Send my clipboard", "Unpair")
        MaterialAlertDialogBuilder(this)
            .setTitle("Send to ${row.name}")
            .setItems(options) { _, which ->
                targetId = row.id
                when (which) {
                    0 -> pickFiles.launch(arrayOf("*/*"))
                    1 -> pickFolder.launch(null)
                    2 -> askText(row.id)
                    3 -> sendClipboard(row.id)
                    4 -> confirmUnpair(row)
                }
            }
            .show()
    }

    private fun confirmUnpair(row: DeviceRow) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Unpair ${row.name}?")
            .setMessage("It will no longer be able to send to this device, and you can't send to it until you pair again.")
            .setPositiveButton("Unpair") { _, _ ->
                Store.removePaired(row.id)
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun startPair(peer: Peer) {
        val code = Proto.pairCode()
        val ref = AtomicReference<Socket?>(null)
        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle("Pair with ${peer.name}")
            .setMessage("A request was sent. Check that this code appears on ${peer.name}, then tap Accept there.\n\n$code")
            .setCancelable(false)
            .setNegativeButton("Cancel") { _, _ ->
                Work.run { try { ref.get()?.close() } catch (e: Exception) { } }
            }
            .show()
        val app = applicationContext
        Work.run {
            val msg = Sender.requestPair(app, peer, code, ref)
            Hub.main.post {
                if (!isFinishing && !isDestroyed && dlg.isShowing) dlg.dismiss()
                Toast.makeText(app, msg, Toast.LENGTH_LONG).show()
                if (!isDestroyed) refresh()
            }
        }
    }

    private fun checkPendingPair() {
        val pp = Hub.pendingPair ?: return
        if (pp === shownPair) return
        shownPair = pp
        MaterialAlertDialogBuilder(this)
            .setTitle("Pair with ${pp.name}?")
            .setMessage(
                "Only accept if this same code is shown on ${pp.name}:\n\n${pp.code}\n\n" +
                    "Paired devices can send files to this device without asking each time."
            )
            .setCancelable(false)
            .setPositiveButton("Accept") { _, _ -> pp.resolve(true) }
            .setNegativeButton("Reject") { _, _ -> pp.resolve(false) }
            .show()
    }

    // ---------------- sending ----------------

    private fun onFilesPicked(uris: List<Uri>) {
        val id = targetId ?: return
        if (uris.isEmpty()) return
        for (u in uris) {
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) { }
        }
        val app = applicationContext
        Work.run {
            try {
                val items = Util.ensureSized(app, uris.map { Util.describeUri(app, it) })
                val title = if (items.size == 1) items[0].relPath else "${items.size} files"
                Sender.sendFiles(app, id, items, title)
            } catch (e: Exception) {
                Hub.main.post { Toast.makeText(app, "Couldn't read files: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun onFolderPicked(tree: Uri) {
        val id = targetId ?: return
        try {
            contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) { }
        val app = applicationContext
        toast("Reading folder…")
        Work.run {
            try {
                val (folder, items) = Util.collectTree(app, tree)
                if (items.isEmpty()) {
                    Hub.main.post { Toast.makeText(app, "That folder has no files", Toast.LENGTH_SHORT).show() }
                } else {
                    Sender.sendFiles(app, id, Util.ensureSized(app, items), "Folder “$folder” (${items.size} files)")
                }
            } catch (e: Exception) {
                Hub.main.post { Toast.makeText(app, "Couldn't read folder: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun askText(id: String) {
        val input = EditText(this)
        input.minLines = 3
        input.hint = "Type or paste text"
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this)
        box.setPadding(pad, pad / 2, pad, 0)
        box.addView(input)
        val app = applicationContext
        MaterialAlertDialogBuilder(this)
            .setTitle("Send text")
            .setView(box)
            .setPositiveButton("Send") { _, _ ->
                val t = input.text.toString()
                if (t.isNotEmpty()) Work.run { Sender.sendText(app, id, t) }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun sendClipboard(id: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this).toString() else ""
        if (text.isEmpty()) {
            toast("Clipboard is empty")
            return
        }
        val app = applicationContext
        Work.run { Sender.sendText(app, id, text) }
        toast("Sending clipboard…")
    }

    // ---------------- history ----------------

    private fun onHistoryClicked(h: HistoryEntry) {
        val t = h.text
        if (h.isText && t != null) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("LanShare", t))
            toast("Text copied")
            return
        }
        val msg = StringBuilder()
        msg.append(if (h.outgoing) "Sent to " else "Received from ").append(h.deviceName).append('\n')
        msg.append(Util.formatTime(h.time)).append('\n')
        msg.append("${h.fileCount} file(s), ${Util.formatBytes(h.totalBytes)}")
        if (h.avgSpeed > 0) msg.append(" at ${Util.formatSpeed(h.avgSpeed)}")
        val err = h.error
        if (err != null) msg.append("\n\n").append(err)
        if (!h.outgoing && h.status == HistoryEntry.FAILED) {
            msg.append("\n\nAsk the sender to tap Retry — it will continue from where it stopped.")
        }
        if (!h.outgoing && h.status == HistoryEntry.DONE) {
            msg.append("\n\nSaved in: ").append(Prefs.receiveDir(this).absolutePath)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(h.title)
            .setMessage(msg.toString())
            .setPositiveButton("OK", null)
            .show()
    }
}

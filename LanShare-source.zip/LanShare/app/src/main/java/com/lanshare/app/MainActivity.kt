package com.lanshare.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var deviceAdapter: DeviceAdapter
    private lateinit var historyAdapter: HistoryAdapter
    private lateinit var boxTransfers: LinearLayout
    private lateinit var headerTransfers: TextView
    private lateinit var txtNoDevices: TextView
    private lateinit var txtNoHistory: TextView
    private lateinit var txtTargets: TextView
    private lateinit var cardWarn: View
    private lateinit var txtWarn: TextView
    private lateinit var btnWarn: Button
    private lateinit var sendButtons: List<Button>

    /** Devices the current pick (files / folder) will go to. */
    private var pendingTargets: List<String> = emptyList()
    private var lastHistoryVersion = -1
    private val transferViews = HashMap<String, View>()

    private val hubListener: () -> Unit = { refresh() }
    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            Hub.main.postDelayed(this, 2000)
        }
    }

    private val pickFiles =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> onFilesPicked(uris) }
    private val pickFolderSystem =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) onSystemFolderPicked(uri) }
    private val pickFolderInApp =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val path = res.data?.getStringExtra(FolderPickerActivity.EXTRA_PATH)
            if (res.resultCode == RESULT_OK && path != null) onLocalFolderPicked(File(path))
        }
    private val askPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById<MaterialToolbar>(R.id.toolbar))
        pendingTargets = savedInstanceState?.getStringArray("targets")?.toList() ?: emptyList()

        boxTransfers = findViewById(R.id.boxTransfers)
        headerTransfers = findViewById(R.id.headerTransfers)
        txtNoDevices = findViewById(R.id.txtNoDevices)
        txtNoHistory = findViewById(R.id.txtNoHistory)
        txtTargets = findViewById(R.id.txtTargets)
        cardWarn = findViewById(R.id.cardWarn)
        txtWarn = findViewById(R.id.txtWarn)
        btnWarn = findViewById(R.id.btnWarn)

        deviceAdapter = DeviceAdapter(
            isSelected = { id -> Hub.isSelected(this, id) },
            onTap = { row -> Hub.toggle(this, row.id); refresh() },
            onLongPress = { row -> onDeviceLongPress(row) }
        )
        findViewById<RecyclerView>(R.id.listDevices).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = deviceAdapter
            isNestedScrollingEnabled = false
        }

        historyAdapter = HistoryAdapter(
            onClick = { h -> onHistoryClicked(h) },
            onRetry = { h ->
                val app = applicationContext
                Work.run { Sender.retry(app, h) }
            }
        )
        findViewById<RecyclerView>(R.id.listHistory).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = historyAdapter
            isNestedScrollingEnabled = false
        }

        findViewById<Button>(R.id.btnClearHistory).setOnClickListener {
            Store.clearHistory()
            refresh()
        }

        val bFiles = findViewById<Button>(R.id.btnFiles)
        val bFolder = findViewById<Button>(R.id.btnFolder)
        val bText = findViewById<Button>(R.id.btnText)
        val bClip = findViewById<Button>(R.id.btnClip)
        sendButtons = listOf(bFiles, bFolder, bText, bClip)
        bFiles.setOnClickListener { startSend(KIND_FILES, selectedIds()) }
        bFolder.setOnClickListener { startSend(KIND_FOLDER, selectedIds()) }
        bText.setOnClickListener { startSend(KIND_TEXT, selectedIds()) }
        bClip.setOnClickListener { startSend(KIND_CLIP, selectedIds()) }

        TransferService.start(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val app = applicationContext
        Work.run { Util.trimUriGrants(app) }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putStringArray("targets", pendingTargets.toTypedArray())
    }

    override fun onResume() {
        super.onResume()
        TransferService.start(this)
        Hub.addListener(hubListener)
        lastHistoryVersion = -1
        Hub.main.post(ticker)
    }

    override fun onPause() {
        Hub.removeListener(hubListener)
        Hub.main.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_refresh -> {
                Discovery.current?.announceAsync()
                refresh()
                toast("Searching for devices…")
            }
            R.id.menu_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            R.id.menu_exit -> {
                TransferService.stop(this)
                finishAffinity()
            }
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    // ---------------- screen ----------------

    private fun refresh() {
        if (isDestroyed) return
        val ip = Util.localIps().firstOrNull() ?: "no Wi-Fi"
        supportActionBar?.subtitle = "${Prefs.deviceName(this)} • $ip"

        when {
            !Util.hasStorageAccess(this) -> {
                cardWarn.visibility = View.VISIBLE
                txtWarn.text = "Allow file access so incoming files are saved automatically and folders can be sent without extra questions."
                btnWarn.setOnClickListener {
                    Util.requestStorageAccess(this) { askPermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE) }
                }
            }
            !Util.isIgnoringBattery(this) -> {
                cardWarn.visibility = View.VISIBLE
                txtWarn.text = "Allow LanShare to run in the background, so it keeps receiving when the screen is off."
                btnWarn.setOnClickListener { Util.requestBatteryExemption(this) }
            }
            else -> cardWarn.visibility = View.GONE
        }

        val rows = Hub.deviceRows()
        deviceAdapter.submit(rows)
        txtNoDevices.visibility = if (rows.any { it.peer != null }) View.GONE else View.VISIBLE

        val on = Hub.selectedOnline(this)
        val off = Hub.selectedOffline(this)
        val onNames = on.joinToString(", ") { if (it.state == Hub.ASLEEP) "${it.name} (screen off)" else it.name }
        txtTargets.text = when {
            on.isEmpty() && off.isEmpty() -> "Tick one or more devices above"
            on.isEmpty() -> "Ticked devices are offline: " + off.joinToString(", ") { it.name }
            off.isEmpty() -> "Sending to: $onNames"
            else -> "Sending to: $onNames" +
                "  (offline, skipped: " + off.joinToString(", ") { it.name } + ")"
        }
        for (b in sendButtons) b.isEnabled = on.isNotEmpty()

        renderTransfers()

        if (Store.historyVersion != lastHistoryVersion) {
            lastHistoryVersion = Store.historyVersion
            val hist = Store.historyList()
            historyAdapter.submit(hist)
            txtNoHistory.visibility = if (hist.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun renderTransfers() {
        val list = Hub.active.values.sortedBy { it.id }
        headerTransfers.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        val ids = list.map { it.id }.toSet()
        val iter = transferViews.entries.iterator()
        while (iter.hasNext()) {
            val e = iter.next()
            if (e.key !in ids) {
                boxTransfers.removeView(e.value)
                iter.remove()
            }
        }
        for (t in list) {
            val v = transferViews.getOrPut(t.id) {
                val nv = LayoutInflater.from(this).inflate(R.layout.item_transfer, boxTransfers, false)
                boxTransfers.addView(nv)
                nv
            }
            TransferViews.bind(v, t)
        }
    }

    // ---------------- devices ----------------

    private fun selectedIds(): List<String> = Hub.selectedOnline(this).map { it.id }

    private fun onDeviceLongPress(row: DeviceRow) {
        if (row.peer == null) {
            MaterialAlertDialogBuilder(this)
                .setTitle(row.name)
                .setMessage("This device is offline. Remove it from the list? It will come back automatically when it's online again.")
                .setPositiveButton("Forget") { _, _ ->
                    Store.forget(row.id)
                    refresh()
                }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }
        val options = arrayOf("Files", "A folder", "Text", "My clipboard")
        MaterialAlertDialogBuilder(this)
            .setTitle("Send only to ${row.name}")
            .setItems(options) { _, which -> startSend(which, listOf(row.id)) }
            .show()
    }

    // ---------------- sending ----------------

    private fun startSend(kind: Int, ids: List<String>) {
        if (ids.isEmpty()) {
            toast("Tick at least one online device")
            return
        }
        pendingTargets = ids
        when (kind) {
            KIND_FILES -> pickFiles.launch(arrayOf("*/*"))
            KIND_FOLDER -> {
                if (Util.hasStorageAccess(this)) {
                    pickFolderInApp.launch(Intent(this, FolderPickerActivity::class.java))
                } else {
                    pickFolderSystem.launch(null)
                }
            }
            KIND_TEXT -> askText(ids)
            KIND_CLIP -> sendClipboard(ids)
        }
    }

    private fun onFilesPicked(uris: List<Uri>) {
        val ids = pendingTargets
        if (uris.isEmpty() || ids.isEmpty()) return
        for (u in uris) {
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) { }
        }
        val app = applicationContext
        Work.run {
            try {
                val items = Util.ensureSized(app, Util.expandUris(app, uris))
                val title = if (items.size == 1) items[0].relPath else "${items.size} files"
                Sender.sendFilesToMany(app, ids, items, title)
            } catch (e: Exception) {
                Hub.main.post { Toast.makeText(app, "Couldn't read files: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun onLocalFolderPicked(dir: File) {
        val ids = pendingTargets
        if (ids.isEmpty()) return
        Prefs.setLastFolder(this, dir.absolutePath)
        val app = applicationContext
        toast("Reading folder…")
        Work.run {
            try {
                val items = Util.collectDir(dir)
                if (items.isEmpty()) {
                    Hub.main.post { Toast.makeText(app, "That folder has no files", Toast.LENGTH_SHORT).show() }
                } else {
                    Sender.sendFilesToMany(app, ids, items, "Folder “${dir.name}” (${items.size} files)")
                }
            } catch (e: Exception) {
                Hub.main.post { Toast.makeText(app, "Couldn't read folder: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    /** Fallback when file access isn't allowed yet (uses Android's picker). */
    private fun onSystemFolderPicked(tree: Uri) {
        val ids = pendingTargets
        if (ids.isEmpty()) return
        try {
            contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) { }
        val app = applicationContext
        toast("Reading folder…")
        Work.run {
            try {
                val (folder, items) = Util.collectTree(app, tree)
                if (items.isEmpty()) {
                    Hub.main.post { Toast.makeText(app, "That folder has no files", Toast.LENGTH_SHORT).show() }
                } else {
                    Sender.sendFilesToMany(app, ids, Util.ensureSized(app, items), "Folder “$folder” (${items.size} files)")
                }
            } catch (e: Exception) {
                Hub.main.post { Toast.makeText(app, "Couldn't read folder: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun askText(ids: List<String>) {
        val input = EditText(this)
        input.minLines = 3
        input.hint = "Type or paste text"
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = FrameLayout(this)
        box.setPadding(pad, pad / 2, pad, 0)
        box.addView(input)
        val app = applicationContext
        MaterialAlertDialogBuilder(this)
            .setTitle(if (ids.size == 1) "Send text to ${Hub.nameOf(ids[0])}" else "Send text to ${ids.size} devices")
            .setView(box)
            .setPositiveButton("Send") { _, _ ->
                val t = input.text.toString()
                if (t.isNotEmpty()) Sender.sendTextToMany(app, ids, t)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun sendClipboard(ids: List<String>) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val text = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).coerceToText(this).toString() else ""
        if (text.isEmpty()) {
            toast("Clipboard is empty")
            return
        }
        Sender.sendTextToMany(applicationContext, ids, text)
        toast("Sending clipboard…")
    }

    // ---------------- history ----------------

    private fun onHistoryClicked(h: HistoryEntry) {
        val t = h.text
        if (h.isText && t != null) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("LanShare", t))
            toast("Text copied")
            return
        }
        val msg = StringBuilder()
        msg.append(if (h.outgoing) "Sent to " else "Received from ").append(h.deviceName).append('\n')
        msg.append(Util.formatTime(h.time)).append('\n')
        msg.append("${h.fileCount} file(s), ${Util.formatBytes(h.totalBytes)}")
        if (h.avgSpeed > 0) msg.append(" at ${Util.formatSpeed(h.avgSpeed)}")
        val err = h.error
        if (err != null) msg.append("\n\n").append(err)
        if (!h.outgoing && h.status == HistoryEntry.FAILED) {
            msg.append("\n\nAsk the sender to tap Retry — it will continue from where it stopped.")
        }
        if (!h.outgoing && h.status == HistoryEntry.DONE) {
            msg.append("\n\nSaved in: ").append(Prefs.receiveDir(this).absolutePath)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(h.title)
            .setMessage(msg.toString())
            .setPositiveButton("OK", null)
            .show()
    }

    companion object {
        private const val KIND_FILES = 0
        private const val KIND_FOLDER = 1
        private const val KIND_TEXT = 2
        private const val KIND_CLIP = 3
    }
}

package com.lanshare.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.media.MediaScannerConnection
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.File
import java.io.FileOutputStream
import java.net.Socket
import java.util.Collections
import kotlin.math.min

/** Handles one incoming connection. Files are accepted automatically from paired devices. */
class Receiver(private val ctx: Context, private val socket: Socket) {
    companion object {
        const val PARTIAL_DIR = ".lanshare-partial"
        private val cancelledBatches: MutableSet<String> = Collections.synchronizedSet(HashSet<String>())

        /** Delete half-received files older than 7 days. */
        fun cleanupPartials(ctx: Context) {
            try {
                val d = File(Prefs.receiveDir(ctx), PARTIAL_DIR)
                val limit = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
                d.listFiles()?.forEach { if (it.name.endsWith(".part") && it.lastModified() < limit) it.delete() }
            } catch (e: Exception) { }
        }
    }

    private class Plan(
        val rel: String, val size: Long, val mtime: Long,
        val dest: File, val part: File, val offset: Long, val skip: Boolean
    )

    private val inp = DataInputStream(BufferedInputStream(socket.getInputStream(), Proto.BUF))
    private val out = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), 64 * 1024))

    fun handle() {
        try {
            Proto.tune(socket)
            socket.soTimeout = 30_000
            val first = Proto.readMsg(inp)
            when (first.optString("type")) {
                "pair_req" -> handlePair(first)
                "hello" -> handleSession(first)
            }
        } catch (e: Exception) {
            Log.w("LanShare", "Connection ended: ${e.message}")
        } finally {
            try { socket.close() } catch (e: Exception) { }
        }
    }

    private fun reject(reason: String) {
        Proto.writeMsg(out, JSONObject().put("type", "reject").put("reason", reason))
    }

    // ---------------- pairing ----------------

    private fun handlePair(m: JSONObject) {
        val id = m.getString("id")
        val name = m.optString("name", "Unknown device")
        val code = m.optString("code")
        val pp = PendingPair(id, name, code)
        Hub.pendingPair = pp
        Hub.notifyChanged()
        Notif.pairRequest(ctx, name, code)
        val ok = pp.await(70)
        if (Hub.pendingPair === pp) Hub.pendingPair = null
        Notif.cancelPair(ctx)
        Hub.notifyChanged()
        if (ok) {
            val secret = Proto.randomB64(32)
            Store.addPaired(PairedDevice(id, name, secret))
            Proto.writeMsg(
                out, JSONObject().put("type", "pair_ok").put("secret", secret).put("name", Prefs.deviceName(ctx))
            )
            Hub.notifyChanged()
        } else {
            Proto.writeMsg(out, JSONObject().put("type", "pair_no"))
        }
    }

    // ---------------- authenticated session ----------------

    private fun handleSession(hello: JSONObject) {
        val peerId = hello.getString("id")
        val peer = Store.getPaired(peerId)
        if (peer == null) {
            Proto.writeMsg(out, JSONObject().put("type", "denied").put("reason", "not_paired"))
            return
        }
        Store.updatePairedName(peerId, hello.optString("name"))
        val nonce = Proto.randomB64(16)
        Proto.writeMsg(out, JSONObject().put("type", "challenge").put("nonce", nonce))
        val auth = Proto.readMsg(inp)
        if (!Proto.macEquals(auth.optString("mac"), Proto.hmac(peer.secret, nonce))) {
            Proto.writeMsg(out, JSONObject().put("type", "denied").put("reason", "bad_auth"))
            return
        }
        Proto.writeMsg(
            out, JSONObject().put("type", "auth_ok").put("mac", Proto.hmac(peer.secret, auth.optString("nonce")))
        )
        val offer = Proto.readMsg(inp)
        val name = Store.getPaired(peerId)?.name ?: peer.name
        when (offer.optString("kind")) {
            "text" -> receiveText(peer, name, offer)
            "files" -> receiveFiles(peer, name, offer)
            else -> reject("Unsupported request — update LanShare on both devices")
        }
    }

    // ---------------- text ----------------

    private fun receiveText(peer: PairedDevice, name: String, offer: JSONObject) {
        val text = offer.optString("text")
        val copy = Prefs.copyTextToClipboard(ctx)
        if (copy) {
            Hub.main.post {
                try {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("LanShare", text))
                } catch (e: Exception) { }
            }
        }
        val h = HistoryEntry(
            id = "in-" + offer.optString("batch", Sender.newId()), time = System.currentTimeMillis(),
            outgoing = false, deviceId = peer.id, deviceName = name, title = Sender.textTitle(text),
            isText = true, fileCount = 0, totalBytes = text.toByteArray(Charsets.UTF_8).size.toLong(),
            status = HistoryEntry.DONE, text = text
        )
        Store.putHistory(h)
        Hub.notifyChanged()
        Proto.writeMsg(out, JSONObject().put("type", "done"))
        Notif.event(ctx, "Text from $name" + (if (copy) " (copied to clipboard)" else ""), text.take(300))
    }

    // ---------------- files ----------------

    private fun receiveFiles(peer: PairedDevice, name: String, offer: JSONObject) {
        val me = Prefs.deviceName(ctx)
        val batch = offer.optString("batch", Sender.newId())
        if (cancelledBatches.contains(batch)) {
            reject("Cancelled on $me")
            return
        }
        if (!Util.hasStorageAccess(ctx)) {
            reject("$me needs file access — open LanShare on $me and tap Allow")
            Notif.event(ctx, "Incoming files blocked", "Open LanShare and allow file access so files from $name can be saved.")
            return
        }
        val base = Prefs.receiveDir(ctx)
        val partDir = File(base, PARTIAL_DIR)
        partDir.mkdirs()
        if (!partDir.isDirectory) {
            reject("$me can't write to its receive folder (${base.absolutePath})")
            return
        }
        try { File(partDir, ".nomedia").createNewFile() } catch (e: Exception) { }

        val policy = Prefs.duplicatePolicy(ctx)
        val arr = offer.getJSONArray("items")
        val plans = ArrayList<Plan>(arr.length())
        val offsets = JSONArray()
        var total = 0L
        var already = 0L
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val rel = Util.safeRelPath(o.getString("path"))
            val size = o.getLong("size")
            val mtime = o.optLong("mtime")
            val dest = File(base, rel)
            val part = File(partDir, Proto.sha1Hex("${peer.id}|$rel|$size|$mtime") + ".part")
            val skip = policy == Prefs.DUP_SKIP && dest.exists()
            var off = 0L
            if (skip) {
                off = size
            } else if (part.exists()) {
                if (part.length() <= size) off = part.length() else part.delete()
            }
            plans.add(Plan(rel, size, mtime, dest, part, off, skip))
            offsets.put(off)
            total += size
            already += off
        }
        Proto.writeMsg(out, JSONObject().put("type", "accept").put("offsets", offsets))

        val hid = "in-$batch"
        val title = offer.optString("title", "${plans.size} files")
        val existing = Store.findHistory(hid)
        val h = if (existing != null) {
            existing.status = HistoryEntry.ACTIVE
            existing.error = null
            existing.time = System.currentTimeMillis()
            existing
        } else {
            HistoryEntry(
                id = hid, time = System.currentTimeMillis(), outgoing = false, deviceId = peer.id,
                deviceName = name, title = title, isText = false, fileCount = plans.size,
                totalBytes = total, status = HistoryEntry.ACTIVE
            )
        }
        Store.putHistory(h)

        val at = ActiveTransfer(hid, false, name, title, total, plans.size)
        at.setStartBytes(already)
        at.status = "Receiving"
        at.onCancel = {
            cancelledBatches.add(batch)
            try { socket.close() } catch (e: Exception) { }
        }
        Hub.active[hid] = at
        Hub.notifyChanged()

        val saved = ArrayList<String>()
        var ok = false
        var err: String? = null
        try {
            socket.soTimeout = 60_000
            val buf = ByteArray(Proto.BUF)
            for (p in plans) {
                if (p.skip) {
                    at.filesDone++
                    continue
                }
                at.currentFile = p.rel
                var remaining = p.size - p.offset
                FileOutputStream(p.part, p.offset > 0).use { fos ->
                    while (remaining > 0) {
                        val n = inp.read(buf, 0, min(buf.size.toLong(), remaining).toInt())
                        if (n < 0) throw EOFException("Connection closed by sender")
                        fos.write(buf, 0, n)
                        remaining -= n
                        at.addBytes(n)
                    }
                }
                saved.add(finalizeFile(p, policy).absolutePath)
                at.filesDone++
            }
            Proto.writeMsg(out, JSONObject().put("type", "done"))
            ok = true
        } catch (e: Exception) {
            err = if (at.cancelled) null else (e.message ?: "Connection lost")
        }

        Hub.active.remove(hid)
        h.status = when {
            ok -> HistoryEntry.DONE
            at.cancelled -> HistoryEntry.CANCELLED
            else -> HistoryEntry.FAILED
        }
        h.error = err
        h.avgSpeed = at.averageSpeed()
        Store.putHistory(h)
        Hub.notifyChanged()
        if (saved.isNotEmpty()) {
            try { MediaScannerConnection.scanFile(ctx, saved.toTypedArray(), null, null) } catch (e: Exception) { }
        }
        if (ok) {
            Notif.event(ctx, "Received from $name", "$title — ${Util.formatBytes(total)} saved in ${base.name}")
        }
    }

    /** Move the finished .part file into place, applying the duplicate rule and original date. */
    private fun finalizeFile(p: Plan, policy: Int): File {
        p.dest.parentFile?.mkdirs()
        var target = p.dest
        if (target.exists()) {
            val replaced = policy == Prefs.DUP_OVERWRITE && target.isFile && target.delete()
            if (!replaced) target = Util.uniqueFile(target)
        }
        if (!p.part.renameTo(target)) {
            p.part.copyTo(target, overwrite = true)
            p.part.delete()
        }
        if (p.mtime > 0) target.setLastModified(p.mtime)
        return target
    }
}

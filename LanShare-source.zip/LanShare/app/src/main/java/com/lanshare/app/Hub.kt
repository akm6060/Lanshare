package com.lanshare.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArraySet
import java.util.concurrent.atomic.AtomicBoolean

/** Shared live state: discovered devices, running transfers, chosen targets. */
object Hub {
    const val ONLINE_MS = 15_000L
    const val ASLEEP_MS = 30_000L
    const val ONLINE = 0
    const val ASLEEP = 1
    const val OFFLINE = 2

    val main = Handler(Looper.getMainLooper())
    val discovered = ConcurrentHashMap<String, Peer>()
    val active = ConcurrentHashMap<String, ActiveTransfer>()

    private val listeners = CopyOnWriteArraySet<() -> Unit>()
    private val scheduled = AtomicBoolean(false)

    fun addListener(l: () -> Unit) { listeners.add(l) }

    fun removeListener(l: () -> Unit) { listeners.remove(l) }

    /** Ask the UI to refresh; many calls in a short time are merged into one. */
    fun notifyChanged() {
        if (scheduled.compareAndSet(false, true)) {
            main.postDelayed({
                scheduled.set(false)
                for (l in listeners) l()
            }, 200)
        }
    }

    /** Age of the last sign of life → state. Devices with screen off are "asleep", not gone. */
    fun stateOf(id: String): Int {
        val p = discovered[id] ?: return OFFLINE
        val age = System.currentTimeMillis() - p.lastSeen
        return when {
            age < ONLINE_MS -> ONLINE
            age < ASLEEP_MS -> ASLEEP
            else -> OFFLINE
        }
    }

    fun onlinePeer(id: String): Peer? = discovered[id]?.takeIf { stateOf(id) == ONLINE }

    /** Online or asleep: worth trying to connect (a connection wakes the other phone). */
    fun reachablePeer(id: String): Peer? = discovered[id]?.takeIf { stateOf(id) != OFFLINE }

    /** A device announced itself or contacted us. */
    fun seen(id: String, name: String, ip: String, port: Int) {
        if (id.isEmpty()) return
        val before = stateOf(id)
        val old = discovered[id]
        discovered[id] = Peer(id, name, ip, port, System.currentTimeMillis())
        Store.remember(id, name)
        if (before != ONLINE || old == null || old.name != name || old.ip != ip) notifyChanged()
    }

    /** Any successful contact keeps a device online. */
    fun touch(id: String, ip: String? = null) {
        val p = discovered[id] ?: return
        val before = stateOf(id)
        discovered[id] = p.copy(ip = ip ?: p.ip, lastSeen = System.currentTimeMillis())
        if (before != ONLINE) notifyChanged()
    }

    fun nameOf(id: String): String =
        discovered[id]?.name ?: Store.getKnown(id)?.name ?: "device"

    /** Online and screen-off devices only, sorted by name so rows never jump around. */
    fun deviceRows(): List<DeviceRow> {
        val rows = LinkedHashMap<String, DeviceRow>()
        for (p in discovered.values) {
            val st = stateOf(p.id)
            if (st != OFFLINE) rows[p.id] = DeviceRow(p.id, p.name, p, st)
        }
        // Offline devices are not listed; they reappear by themselves when they come back.
        return rows.values.sortedBy { it.name.lowercase() }
    }

    // ---------- remembered "send to" selection ----------

    /** Until the user changes it, every device is selected. */
    fun isSelected(ctx: Context, id: String): Boolean {
        val s = Prefs.selectedTargets(ctx)
        return s == null || s.contains(id)
    }

    fun toggle(ctx: Context, id: String) {
        val cur = Prefs.selectedTargets(ctx)?.toMutableSet()
            ?: deviceRows().map { it.id }.toMutableSet()
        if (!cur.add(id)) cur.remove(id)
        Prefs.setSelectedTargets(ctx, cur)
        notifyChanged()
    }

    fun selectedOnline(ctx: Context): List<DeviceRow> =
        deviceRows().filter { it.peer != null && isSelected(ctx, it.id) }

    fun selectedOffline(ctx: Context): List<DeviceRow> =
        deviceRows().filter { it.peer == null && isSelected(ctx, it.id) }
}

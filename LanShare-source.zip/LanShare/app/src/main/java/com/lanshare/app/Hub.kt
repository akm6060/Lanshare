package com.lanshare.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArraySet
import java.util.concurrent.atomic.AtomicBoolean

/** Shared live state: discovered devices, running transfers, chosen targets. */
object Hub {
    const val ONLINE_MS = 12_000L

    val main = Handler(Looper.getMainLooper())
    val discovered = ConcurrentHashMap<String, Peer>()
    val active = ConcurrentHashMap<String, ActiveTransfer>()

    private val listeners = CopyOnWriteArraySet<() -> Unit>()
    private val scheduled = AtomicBoolean(false)

    fun addListener(l: () -> Unit) { listeners.add(l) }

    fun removeListener(l: () -> Unit) { listeners.remove(l) }

    /** Ask the UI to refresh; many calls in a short time are merged into one. */
    fun notifyChanged() {
        if (scheduled.compareAndSet(false, true)) {
            main.postDelayed({
                scheduled.set(false)
                for (l in listeners) l()
            }, 200)
        }
    }

    fun onlinePeer(id: String): Peer? {
        val p = discovered[id] ?: return null
        return if (System.currentTimeMillis() - p.lastSeen < ONLINE_MS) p else null
    }

    fun nameOf(id: String): String =
        onlinePeer(id)?.name ?: Store.getKnown(id)?.name ?: "device"

    /** Online devices first, then remembered offline ones. */
    fun deviceRows(): List<DeviceRow> {
        val rows = LinkedHashMap<String, DeviceRow>()
        for (p in discovered.values) {
            if (onlinePeer(p.id) != null) rows[p.id] = DeviceRow(p.id, p.name, p)
        }
        for (d in Store.knownList()) {
            if (!rows.containsKey(d.id)) rows[d.id] = DeviceRow(d.id, d.name, null)
        }
        return rows.values.sortedWith(
            compareBy<DeviceRow>({ if (it.peer != null) 0 else 1 }, { it.name.lowercase() })
        )
    }

    // ---------- remembered "send to" selection ----------

    /** Until the user changes it, every device is selected. */
    fun isSelected(ctx: Context, id: String): Boolean {
        val s = Prefs.selectedTargets(ctx)
        return s == null || s.contains(id)
    }

    fun toggle(ctx: Context, id: String) {
        val cur = Prefs.selectedTargets(ctx)?.toMutableSet()
            ?: deviceRows().map { it.id }.toMutableSet()
        if (!cur.add(id)) cur.remove(id)
        Prefs.setSelectedTargets(ctx, cur)
        notifyChanged()
    }

    fun selectedOnline(ctx: Context): List<DeviceRow> =
        deviceRows().filter { it.peer != null && isSelected(ctx, it.id) }

    fun selectedOffline(ctx: Context): List<DeviceRow> =
        deviceRows().filter { it.peer == null && isSelected(ctx, it.id) }
}

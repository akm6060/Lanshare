package com.lanshare.app

import android.os.Handler
import android.os.Looper
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArraySet
import java.util.concurrent.atomic.AtomicBoolean

/** Shared live state: discovered devices, running transfers, pairing requests. */
object Hub {
    const val ONLINE_MS = 12_000L

    val main = Handler(Looper.getMainLooper())
    val discovered = ConcurrentHashMap<String, Peer>()
    val active = ConcurrentHashMap<String, ActiveTransfer>()
    @Volatile var pendingPair: PendingPair? = null

    private val listeners = CopyOnWriteArraySet<() -> Unit>()
    private val scheduled = AtomicBoolean(false)

    fun addListener(l: () -> Unit) { listeners.add(l) }

    fun removeListener(l: () -> Unit) { listeners.remove(l) }

    /** Ask the UI to refresh; many calls in a short time are merged into one. */
    fun notifyChanged() {
        if (scheduled.compareAndSet(false, true)) {
            main.postDelayed({
                scheduled.set(false)
                for (l in listeners) l()
            }, 200)
        }
    }

    fun onlinePeer(id: String): Peer? {
        val p = discovered[id] ?: return null
        return if (System.currentTimeMillis() - p.lastSeen < ONLINE_MS) p else null
    }

    fun deviceRows(): List<DeviceRow> {
        val rows = LinkedHashMap<String, DeviceRow>()
        val paired = Store.pairedList().associateBy { it.id }
        for (p in discovered.values) {
            if (onlinePeer(p.id) == null) continue
            rows[p.id] = DeviceRow(p.id, paired[p.id]?.name ?: p.name, paired.containsKey(p.id), p)
        }
        for (d in paired.values) {
            if (!rows.containsKey(d.id)) rows[d.id] = DeviceRow(d.id, d.name, true, null)
        }
        return rows.values.sortedWith(
            compareBy<DeviceRow>(
                { if (it.peer != null && it.paired) 0 else if (it.peer != null) 1 else 2 },
                { it.name.lowercase() }
            )
        )
    }
}

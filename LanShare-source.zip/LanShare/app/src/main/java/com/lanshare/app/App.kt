package com.lanshare.app

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        AutoSend.init(this)
        Work.init(this)
        Notif.createChannels(this)
    }
}

package com.lanshare.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Starts LanShare after the phone restarts or after the app is updated. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val a = intent.action ?: return
        if (a == Intent.ACTION_BOOT_COMPLETED || a == Intent.ACTION_MY_PACKAGE_REPLACED ||
            a == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            if (Prefs.startOnBoot(context)) TransferService.start(context)
        }
    }
}

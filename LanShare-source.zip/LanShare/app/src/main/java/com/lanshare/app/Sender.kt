package com.lanshare.app

import android.content.Context
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.Closeable
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.net.Socket
import java.util.UUID
import kotlin.math.min

object Sender {
    private const val MAX_RETRIES = 3

    private class Conn(val socket: Socket) : Closeable {
        val inp = DataInputStream(BufferedInputStream(socket.getInputStream(), Proto.BUF))
        val out = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), Proto.BUF))
        override fun close() {
            try { socket.close() } catch (e: Exception) { }
        }
    }

    fun newId(): String = UUID.randomUUID().toString()

    fun textTitle(t: String): String = "Text: " + t.trim().replace('\n', ' ').take(60)

    private fun toast(ctx: Context, msg: String) {
        Hub.main.post { Toast.makeText(ctx.applicationContext, msg, Toast.LENGTH_SHORT).show() }
    }

    // ---------------- several devices at once ----------------

    /** Sends the same files to every device in [ids], all in parallel. */
    fun sendFilesToMany(ctx: Context, ids: List<String>, items: List<SendItem>, title: String) {
        for (id in ids) Work.run { sendFiles(ctx, id, items, title) }
    }

    fun sendTextToMany(ctx: Context, ids: List<String>, text: String) {
        for (id in ids) Work.run { sendText(ctx, id, text) }
    }

    // ---------------- connection ----------------

    private fun reasonOf(o: JSONObject, name: String): String {
        val r = o.optString("reason")
        return if (r.isEmpty()) "Rejected by $name" else r
    }

    private fun open(ctx: Context, deviceId: String): Conn {
        val name = Hub.nameOf(deviceId)
        val peer = Hub.reachablePeer(deviceId) ?: throw IOException("$name is offline")
        val c = Conn(Proto.connect(peer.ip, peer.port))
        Hub.touch(deviceId)
        try {
            Proto.writeMsg(
                c.out, JSONObject()
                    .put("type", "hello")
                    .put("id", Prefs.deviceId(ctx))
                    .put("name", Prefs.deviceName(ctx))
                    .put("v", Proto.VERSION)
            )
            val r = Proto.readMsg(c.inp)
            if (r.optString("type") != "ok") {
                throw FatalTransferException(
                    if (r.optString("reason").isEmpty()) "Update LanShare on $name to the same version" else reasonOf(r, name)
                )
            }
            return c
        } catch (e: Exception) {
            c.close()
            throw e
        }
    }

    // ---------------- files & folders ----------------

    /**
     * Returns true when everything arrived.
     * [auto] = sent by auto-send: the receiver replaces a file with the same name, and failures are
     * retried by AutoSend itself (no "tap Retry" notification).
     */
    fun sendFiles(
        ctx: Context, deviceId: String, items: List<SendItem>, title: String,
        id: String = newId(), auto: Boolean = false, sourcePaths: List<String>? = null
    ): Boolean {
        val name = Hub.nameOf(deviceId)
        val total = items.sumOf { it.size }
        val existing = Store.findHistory(id)
        val h = if (existing != null) {
            existing.status = HistoryEntry.ACTIVE
            existing.error = null
            existing.time = System.currentTimeMillis()
            existing
        } else {
            HistoryEntry(
                id = id, time = System.currentTimeMillis(), outgoing = true,
                deviceId = deviceId, deviceName = name, title = title, isText = false,
                fileCount = items.size, totalBytes = total, status = HistoryEntry.ACTIVE, items = items,
                replace = auto,
                files = (sourcePaths ?: items.map { Util.refOf(it.uri) }).take(HistoryEntry.MAX_FILES)
            )
        }
        val replace = auto || h.replace
        Store.putHistory(h)

        val at = ActiveTransfer(id, true, name, title, total, items.size)
        Hub.active[id] = at
        Hub.notifyChanged()

        var ok = false
        var error: String? = null
        var attempt = 0
        while (true) {
            try {
                doSend(ctx, deviceId, name, items, at, replace)
                ok = true
                break
            } catch (e: FatalTransferException) {
                error = e.message
                break
            } catch (e: Exception) {
                error = e.message ?: e.javaClass.simpleName
                if (at.cancelled || attempt >= MAX_RETRIES) break
                attempt++
                at.status = "Connection lost — retrying ($attempt/$MAX_RETRIES)…"
                Hub.notifyChanged()
                try { Thread.sleep(3000) } catch (ie: InterruptedException) { break }
                if (at.cancelled) break
            }
        }

        Hub.active.remove(id)
        h.status = when {
            ok -> HistoryEntry.DONE
            at.cancelled -> HistoryEntry.CANCELLED
            else -> HistoryEntry.FAILED
        }
        h.avgSpeed = at.averageSpeed()
        h.error = if (ok || at.cancelled) null else error
        if (ok) h.items = emptyList()
        Store.putHistory(h)
        Hub.notifyChanged()
        if (ok) toast(ctx, if (auto) "Sent “$title” to $name" else "Sent to $name")
        else if (!at.cancelled && !auto) Notif.event(ctx, "Sending to $name failed", "$title\n${error ?: ""}\nTap Retry in History to continue.")
        return ok
    }

    private fun doSend(
        ctx: Context, deviceId: String, name: String, items: List<SendItem>, at: ActiveTransfer, replace: Boolean
    ) {
        at.status = "Connecting…"
        Hub.notifyChanged()
        open(ctx, deviceId).use { c ->
            at.onCancel = { c.close() }
            if (at.cancelled) throw IOException("Cancelled")
            val arr = JSONArray()
            for (item in items) {
                arr.put(JSONObject().put("path", item.relPath).put("size", item.size).put("mtime", item.mtime))
            }
            val offer = JSONObject()
                .put("type", "offer").put("kind", "files")
                .put("batch", at.id).put("title", at.title).put("items", arr)
            if (replace) offer.put("replace", true)
            Proto.writeMsg(c.out, offer)
            c.socket.soTimeout = 120_000
            val acc = Proto.readMsg(c.inp)
            if (acc.optString("type") != "accept") throw FatalTransferException(reasonOf(acc, name))
            c.socket.soTimeout = 60_000
            val offsets = acc.getJSONArray("offsets")
            if (offsets.length() != items.size) throw FatalTransferException("Version mismatch — update LanShare on both devices")

            var already = 0L
            for (i in items.indices) already += min(offsets.getLong(i), items[i].size)
            at.setStartBytes(already)
            at.filesDone = 0
            at.status = "Sending"
            Hub.notifyChanged()

            val buf = ByteArray(Proto.BUF)
            for (i in items.indices) {
                val item = items[i]
                val off = offsets.getLong(i)
                if (off >= item.size) {
                    at.filesDone++
                    continue
                }
                at.currentFile = item.relPath
                var opened: InputStream? = null
                try {
                    opened = ctx.contentResolver.openInputStream(item.uri)
                } catch (e: Exception) { }
                val ins = opened ?: throw FatalTransferException("Can't read ${item.relPath} any more — pick it again")
                ins.use { stream ->
                    skipFully(stream, off)
                    var remaining = item.size - off
                    while (remaining > 0) {
                        val n = stream.read(buf, 0, min(buf.size.toLong(), remaining).toInt())
                        if (n < 0) throw FatalTransferException("${item.relPath} changed while sending")
                        c.out.write(buf, 0, n)
                        remaining -= n
                        at.addBytes(n)
                    }
                }
                at.filesDone++
            }
            c.out.flush()
            at.status = "Finishing…"
            Hub.notifyChanged()
            val fin = Proto.readMsg(c.inp)
            if (fin.optString("type") != "done") throw IOException(fin.optString("reason", "Receiver error"))
        }
    }

    private fun skipFully(ins: InputStream, n: Long) {
        var left = n
        val tmp = ByteArray(64 * 1024)
        while (left > 0) {
            val s = ins.skip(left)
            if (s > 0) {
                left -= s
                continue
            }
            val r = ins.read(tmp, 0, min(tmp.size.toLong(), left).toInt())
            if (r < 0) throw EOFException("File is shorter than expected")
            left -= r
        }
    }

    // ---------------- text / clipboard ----------------

    fun sendText(ctx: Context, deviceId: String, text: String) {
        val name = Hub.nameOf(deviceId)
        val id = newId()
        val h = HistoryEntry(
            id = id, time = System.currentTimeMillis(), outgoing = true,
            deviceId = deviceId, deviceName = name, title = textTitle(text), isText = true,
            fileCount = 0, totalBytes = text.toByteArray(Charsets.UTF_8).size.toLong(),
            status = HistoryEntry.ACTIVE, text = text
        )
        Store.putHistory(h)
        Hub.notifyChanged()
        try {
            open(ctx, deviceId).use { c ->
                Proto.writeMsg(
                    c.out, JSONObject().put("type", "offer").put("kind", "text").put("batch", id).put("text", text)
                )
                val fin = Proto.readMsg(c.inp)
                if (fin.optString("type") != "done") throw IOException(reasonOf(fin, name))
            }
            h.status = HistoryEntry.DONE
            toast(ctx, "Text sent to $name")
        } catch (e: Exception) {
            h.status = HistoryEntry.FAILED
            h.error = e.message
            toast(ctx, "Text not sent to $name: ${e.message}")
        }
        Store.putHistory(h)
        Hub.notifyChanged()
    }

    fun retry(ctx: Context, h: HistoryEntry) {
        if (h.isText) {
            val t = h.text ?: return
            sendText(ctx, h.deviceId, t)
            return
        }
        if (h.items.isEmpty()) return
        sendFiles(ctx, h.deviceId, h.items, h.title, h.id)
    }
}

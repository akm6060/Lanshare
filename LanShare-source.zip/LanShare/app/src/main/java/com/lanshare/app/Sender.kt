package com.lanshare.app

import android.content.Context
import android.content.Intent
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.Closeable
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.net.Socket
import java.util.UUID
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.min

object Sender {
    private const val MAX_RETRIES = 3

    private class Conn(val socket: Socket) : Closeable {
        val inp = DataInputStream(BufferedInputStream(socket.getInputStream(), Proto.BUF))
        val out = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), Proto.BUF))
        override fun close() {
            try { socket.close() } catch (e: Exception) { }
        }
    }

    fun newId(): String = UUID.randomUUID().toString()

    fun textTitle(t: String): String = "Text: " + t.trim().replace('\n', ' ').take(60)

    private fun toast(ctx: Context, msg: String) {
        Hub.main.post { Toast.makeText(ctx.applicationContext, msg, Toast.LENGTH_SHORT).show() }
    }

    // ---------------- pairing ----------------

    fun requestPair(ctx: Context, peer: Peer, code: String, socketRef: AtomicReference<Socket?>): String {
        return try {
            val s = Proto.connect(peer.ip, peer.port)
            socketRef.set(s)
            Conn(s).use { c ->
                Proto.writeMsg(
                    c.out, JSONObject()
                        .put("type", "pair_req")
                        .put("id", Prefs.deviceId(ctx))
                        .put("name", Prefs.deviceName(ctx))
                        .put("code", code)
                        .put("v", Proto.VERSION)
                )
                s.soTimeout = 75_000
                val r = Proto.readMsg(c.inp)
                if (r.optString("type") == "pair_ok") {
                    Store.addPaired(PairedDevice(peer.id, r.optString("name", peer.name), r.getString("secret")))
                    Hub.notifyChanged()
                    "Paired with ${peer.name}"
                } else {
                    "${peer.name} rejected the pairing"
                }
            }
        } catch (e: Exception) {
            "Pairing cancelled or failed (${e.message ?: "connection error"})"
        }
    }

    // ---------------- authenticated connection ----------------

    private fun reasonOf(o: JSONObject, peer: PairedDevice): String = when (o.optString("reason")) {
        "not_paired" -> "${peer.name} doesn't recognise this device. Unpair it here and pair again."
        "bad_auth" -> "Pairing keys don't match. Unpair on both devices and pair again."
        "" -> "Rejected by ${peer.name}"
        else -> o.optString("reason")
    }

    private fun openAuthed(ctx: Context, peer: PairedDevice): Conn {
        val online = Hub.onlinePeer(peer.id) ?: throw IOException("${peer.name} is offline")
        val c = Conn(Proto.connect(online.ip, online.port))
        try {
            Proto.writeMsg(
                c.out, JSONObject()
                    .put("type", "hello")
                    .put("id", Prefs.deviceId(ctx))
                    .put("name", Prefs.deviceName(ctx))
                    .put("v", Proto.VERSION)
            )
            val ch = Proto.readMsg(c.inp)
            if (ch.optString("type") != "challenge") throw FatalTransferException(reasonOf(ch, peer))
            val myNonce = Proto.randomB64(16)
            Proto.writeMsg(
                c.out, JSONObject()
                    .put("type", "auth")
                    .put("mac", Proto.hmac(peer.secret, ch.getString("nonce")))
                    .put("nonce", myNonce)
            )
            val ok = Proto.readMsg(c.inp)
            if (ok.optString("type") != "auth_ok") throw FatalTransferException(reasonOf(ok, peer))
            if (!Proto.macEquals(ok.optString("mac"), Proto.hmac(peer.secret, myNonce))) {
                throw FatalTransferException("Couldn't verify ${peer.name}. Unpair and pair again.")
            }
            return c
        } catch (e: Exception) {
            c.close()
            throw e
        }
    }

    // ---------------- files & folders ----------------

    fun sendFiles(ctx: Context, peerId: String, items: List<SendItem>, title: String, id: String = newId()) {
        val peer = Store.getPaired(peerId) ?: return
        val total = items.sumOf { it.size }
        val existing = Store.findHistory(id)
        val h = if (existing != null) {
            existing.status = HistoryEntry.ACTIVE
            existing.error = null
            existing.time = System.currentTimeMillis()
            existing
        } else {
            HistoryEntry(
                id = id, time = System.currentTimeMillis(), outgoing = true,
                deviceId = peer.id, deviceName = peer.name, title = title, isText = false,
                fileCount = items.size, totalBytes = total, status = HistoryEntry.ACTIVE, items = items
            )
        }
        Store.putHistory(h)

        val at = ActiveTransfer(id, true, peer.name, title, total, items.size)
        Hub.active[id] = at
        Hub.notifyChanged()

        var ok = false
        var error: String? = null
        var attempt = 0
        while (true) {
            try {
                doSend(ctx, peer, items, at)
                ok = true
                break
            } catch (e: FatalTransferException) {
                error = e.message
                break
            } catch (e: Exception) {
                error = e.message ?: e.javaClass.simpleName
                if (at.cancelled || attempt >= MAX_RETRIES) break
                attempt++
                at.status = "Connection lost — retrying ($attempt/$MAX_RETRIES)…"
                Hub.notifyChanged()
                try { Thread.sleep(3000) } catch (ie: InterruptedException) { break }
                if (at.cancelled) break
            }
        }

        Hub.active.remove(id)
        h.status = when {
            ok -> HistoryEntry.DONE
            at.cancelled -> HistoryEntry.CANCELLED
            else -> HistoryEntry.FAILED
        }
        h.avgSpeed = at.averageSpeed()
        h.error = if (ok || at.cancelled) null else error
        if (ok) {
            for (item in h.items) {
                try {
                    ctx.contentResolver.releasePersistableUriPermission(item.uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) { }
            }
            h.items = emptyList()
        }
        Store.putHistory(h)
        Hub.notifyChanged()
        if (ok) toast(ctx, "Sent to ${peer.name}")
        else if (!at.cancelled) Notif.event(ctx, "Sending to ${peer.name} failed", "$title\n${error ?: ""}\nTap Retry in History to continue.")
    }

    private fun doSend(ctx: Context, peer: PairedDevice, items: List<SendItem>, at: ActiveTransfer) {
        at.status = "Connecting…"
        Hub.notifyChanged()
        openAuthed(ctx, peer).use { c ->
            at.onCancel = { c.close() }
            if (at.cancelled) throw IOException("Cancelled")
            val arr = JSONArray()
            for (item in items) {
                arr.put(JSONObject().put("path", item.relPath).put("size", item.size).put("mtime", item.mtime))
            }
            Proto.writeMsg(
                c.out, JSONObject()
                    .put("type", "offer").put("kind", "files")
                    .put("batch", at.id).put("title", at.title).put("items", arr)
            )
            c.socket.soTimeout = 120_000
            val acc = Proto.readMsg(c.inp)
            if (acc.optString("type") != "accept") throw FatalTransferException(reasonOf(acc, peer))
            c.socket.soTimeout = 60_000
            val offsets = acc.getJSONArray("offsets")
            if (offsets.length() != items.size) throw FatalTransferException("Version mismatch — update LanShare on both devices")

            var already = 0L
            for (i in items.indices) already += min(offsets.getLong(i), items[i].size)
            at.setStartBytes(already)
            at.filesDone = 0
            at.status = "Sending"
            Hub.notifyChanged()

            val buf = ByteArray(Proto.BUF)
            for (i in items.indices) {
                val item = items[i]
                val off = offsets.getLong(i)
                if (off >= item.size) {
                    at.filesDone++
                    continue
                }
                at.currentFile = item.relPath
                var opened: InputStream? = null
                try {
                    opened = ctx.contentResolver.openInputStream(item.uri)
                } catch (e: Exception) { }
                val ins = opened ?: throw FatalTransferException("Can't read ${item.relPath} any more — pick it again")
                ins.use { stream ->
                    skipFully(stream, off)
                    var remaining = item.size - off
                    while (remaining > 0) {
                        val n = stream.read(buf, 0, min(buf.size.toLong(), remaining).toInt())
                        if (n < 0) throw FatalTransferException("${item.relPath} changed while sending")
                        c.out.write(buf, 0, n)
                        remaining -= n
                        at.addBytes(n)
                    }
                }
                at.filesDone++
            }
            c.out.flush()
            at.status = "Finishing…"
            Hub.notifyChanged()
            val fin = Proto.readMsg(c.inp)
            if (fin.optString("type") != "done") throw IOException(fin.optString("reason", "Receiver error"))
        }
    }

    private fun skipFully(ins: InputStream, n: Long) {
        var left = n
        val tmp = ByteArray(64 * 1024)
        while (left > 0) {
            val s = ins.skip(left)
            if (s > 0) {
                left -= s
                continue
            }
            val r = ins.read(tmp, 0, min(tmp.size.toLong(), left).toInt())
            if (r < 0) throw EOFException("File is shorter than expected")
            left -= r
        }
    }

    // ---------------- text / clipboard ----------------

    fun sendText(ctx: Context, peerId: String, text: String) {
        val peer = Store.getPaired(peerId) ?: return
        val id = newId()
        val h = HistoryEntry(
            id = id, time = System.currentTimeMillis(), outgoing = true,
            deviceId = peer.id, deviceName = peer.name, title = textTitle(text), isText = true,
            fileCount = 0, totalBytes = text.toByteArray(Charsets.UTF_8).size.toLong(),
            status = HistoryEntry.ACTIVE, text = text
        )
        Store.putHistory(h)
        Hub.notifyChanged()
        try {
            openAuthed(ctx, peer).use { c ->
                Proto.writeMsg(
                    c.out, JSONObject().put("type", "offer").put("kind", "text").put("batch", id).put("text", text)
                )
                val fin = Proto.readMsg(c.inp)
                if (fin.optString("type") != "done") throw IOException(reasonOf(fin, peer))
            }
            h.status = HistoryEntry.DONE
            toast(ctx, "Text sent to ${peer.name}")
        } catch (e: Exception) {
            h.status = HistoryEntry.FAILED
            h.error = e.message
            toast(ctx, "Text not sent: ${e.message}")
        }
        Store.putHistory(h)
        Hub.notifyChanged()
    }

    fun retry(ctx: Context, h: HistoryEntry) {
        if (h.isText) {
            val t = h.text ?: return
            sendText(ctx, h.deviceId, t)
            return
        }
        if (h.items.isEmpty()) return
        sendFiles(ctx, h.deviceId, h.items, h.title, h.id)
    }
}

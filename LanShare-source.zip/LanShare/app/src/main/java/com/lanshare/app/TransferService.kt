package com.lanshare.app

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import androidx.core.content.ContextCompat
import java.io.File
import kotlin.concurrent.thread

/** Keeps LanShare discoverable and ready to receive, even with the screen off. */
class TransferService : Service() {
    companion object {
        @Volatile var running = false

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, TransferService::class.java))
            } catch (e: Exception) {
                Log.w("LanShare", "Could not start service: ${e.message}")
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, TransferService::class.java))
        }
    }

    @Volatile private var server: Server? = null
    @Volatile private var discovery: Discovery? = null
    private var lastUpdate = 0L
    private var wasBusy = false
    private val listener: () -> Unit = { updateNotification() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        goForeground()
        Work.setStandby(Prefs.keepAwake(this))
        val app = applicationContext
        thread(name = "lanshare-start", isDaemon = true) {
            try {
                val srv = Server(app)
                srv.start()
                server = srv
                val d = Discovery(app, srv.port)
                d.start()
                discovery = d
            } catch (e: Exception) {
                Log.e("LanShare", "Start failed", e)
            }
            Receiver.cleanupPartials(app)
            cleanupCache(app)
        }
        Hub.addListener(listener)
        updateNotification()
        AutoSend.start(app)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        return START_STICKY
    }

    private fun goForeground() {
        val n = Notif.service(this, "Ready to receive — visible as ${Prefs.deviceName(this)}")
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(Notif.ID_SERVICE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                startForeground(Notif.ID_SERVICE, n)
            }
        } catch (e: Exception) {
            Log.w("LanShare", "startForeground failed: ${e.message}")
        }
    }

    override fun onDestroy() {
        running = false
        AutoSend.stop()
        Work.setStandby(false)
        Hub.removeListener(listener)
        discovery?.stop()
        server?.stop()
        super.onDestroy()
    }

    private fun cleanupCache(ctx: Context) {
        try {
            val limit = System.currentTimeMillis() - 3L * 24 * 3600 * 1000
            File(ctx.cacheDir, "share").listFiles()?.forEach {
                if (it.lastModified() < limit) it.deleteRecursively()
            }
        } catch (e: Exception) { }
    }

    private fun updateNotification() {
        val list = Hub.active.values.toList()
        val now = SystemClock.elapsedRealtime()
        if (list.isNotEmpty() && wasBusy && now - lastUpdate < 1000) return
        lastUpdate = now
        wasBusy = list.isNotEmpty()
        val n = if (list.isEmpty()) {
            Notif.service(this, "Ready to receive — visible as ${Prefs.deviceName(this)}")
        } else {
            val total = list.sumOf { it.totalBytes }
            val done = list.sumOf { it.doneBytes }
            val pct = if (total > 0) (done * 100 / total).toInt() else 0
            val t = list.first()
            val dir = if (t.outgoing) "Sending to" else "Receiving from"
            Notif.service(this, "$dir ${t.deviceName} — $pct% • ${Util.formatSpeed(t.speed)}", pct)
        }
        Notif.updateService(this, n)
    }
}

package com.lanshare.app

import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import java.io.File

/**
 * LanShare's own folder browser. Because LanShare already has file access,
 * no "Allow access to folder?" question is needed.
 */
class FolderPickerActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_PATH = "path"
    }

    @Suppress("DEPRECATION")
    private val root: File = Environment.getExternalStorageDirectory()
    private var current: File = root
    private var folders: List<File> = emptyList()

    private lateinit var toolbar: MaterialToolbar
    private lateinit var txtPath: TextView
    private lateinit var txtNone: TextView
    private lateinit var btnSend: Button
    private lateinit var adapter: FolderAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_folder_picker)
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { goUpOrClose() }
        txtPath = findViewById(R.id.txtPath)
        txtNone = findViewById(R.id.txtNoFolders)
        btnSend = findViewById(R.id.btnSendHere)

        adapter = FolderAdapter { f -> open(f) }
        val list = findViewById<RecyclerView>(R.id.listFolders)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        btnSend.setOnClickListener {
            setResult(RESULT_OK, Intent().putExtra(EXTRA_PATH, current.absolutePath))
            finish()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goUpOrClose()
        })

        // Start where the last sent folder was, to save taps.
        val start = savedInstanceState?.getString("cur")
            ?: Prefs.lastFolder(this)?.let { File(it).parent }
        val startDir = start?.let { File(it) }
        open(if (startDir != null && startDir.isDirectory && startDir.absolutePath.startsWith(root.absolutePath)) startDir else root)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("cur", current.absolutePath)
    }

    private fun goUpOrClose() {
        val parent = current.parentFile
        if (current.absolutePath == root.absolutePath || parent == null) finish() else open(parent)
    }

    private fun open(dir: File) {
        current = dir
        folders = (dir.listFiles() ?: emptyArray())
            .filter { it.isDirectory && !it.name.startsWith(".") }
            .sortedBy { it.name.lowercase() }
        adapter.submit(folders)
        val atRoot = dir.absolutePath == root.absolutePath
        toolbar.title = if (atRoot) "Phone storage" else dir.name
        txtPath.text = dir.absolutePath.removePrefix(root.absolutePath).ifEmpty { "/" }
        txtNone.visibility = if (folders.isEmpty()) View.VISIBLE else View.GONE
        btnSend.text = if (atRoot) "Open a folder to send it" else "Send “${dir.name}”"
        btnSend.isEnabled = !atRoot
    }

    private class FolderAdapter(private val onOpen: (File) -> Unit) : RecyclerView.Adapter<FolderAdapter.VH>() {
        private var items: List<File> = emptyList()

        fun submit(l: List<File>) {
            items = l
            notifyDataSetChanged()
        }

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val name: TextView = v.findViewById(R.id.txtFolderName)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_folder, parent, false))

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val f = items[position]
            h.name.text = f.name
            h.itemView.setOnClickListener { onOpen(f) }
        }
    }
}

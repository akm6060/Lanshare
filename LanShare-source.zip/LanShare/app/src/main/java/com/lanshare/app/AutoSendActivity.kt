package com.lanshare.app

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File

/** Settings for auto-send (replaces the auto-clicker) and the daily move to the backup folder. */
class AutoSendActivity : AppCompatActivity() {
    private lateinit var folderList: LinearLayout
    private lateinit var targetList: LinearLayout
    private lateinit var txtNoTargets: TextView
    private lateinit var txtStatus: TextView
    private lateinit var txtWarn: TextView
    private lateinit var btnAllow: Button
    private lateinit var txtFrom: TextView
    private lateinit var txtTo: TextView
    private lateinit var txtLog: TextView
    private lateinit var txtActivity: TextView

    private var pickFor = ""
    private var ticks = 0

    private val ticker = object : Runnable {
        override fun run() {
            renderStatus()
            if (++ticks % 5 == 0) renderTargets() // refresh online / offline labels
            Hub.main.postDelayed(this, 1000)
        }
    }

    private val pickFolder =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val path = res.data?.getStringExtra(FolderPickerActivity.EXTRA_PATH)
            if (res.resultCode == RESULT_OK && path != null) onPicked(pickFor, path)
        }

    private val askLegacy =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { render() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auto_send)
        val tb = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(tb)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        tb.setNavigationOnClickListener { finish() }
        pickFor = savedInstanceState?.getString("pickFor") ?: ""

        folderList = findViewById(R.id.listAutoFolders)
        targetList = findViewById(R.id.listAutoTargets)
        txtNoTargets = findViewById(R.id.txtNoTargets)
        txtStatus = findViewById(R.id.txtAutoStatus)
        txtWarn = findViewById(R.id.txtAccessWarn)
        btnAllow = findViewById(R.id.btnAllowAccess)
        txtFrom = findViewById(R.id.txtMoveFrom)
        txtTo = findViewById(R.id.txtMoveTo)
        txtLog = findViewById(R.id.txtMoveLog)
        txtActivity = findViewById(R.id.txtActivity)

        btnAllow.setOnClickListener {
            Util.requestStorageAccess(this) { askLegacy.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE) }
        }

        // ---------- auto-send ----------
        val swAuto = findViewById<SwitchCompat>(R.id.switchAuto)
        swAuto.isChecked = Prefs.autoSendEnabled(this)
        swAuto.setOnCheckedChangeListener { _, on ->
            Prefs.setAutoSendEnabled(this, on)
            if (on) {
                Prefs.requestAutoRebaseline(this)
                TransferService.start(this)
                if (Prefs.autoFolders(this).isEmpty()) toast("Now add the folder(s) to watch")
            }
            AutoSend.configChanged()
            renderStatus()
        }

        findViewById<Button>(R.id.btnAddFolder).setOnClickListener { pick("watch", null) }

        val editSub = findViewById<EditText>(R.id.editAutoSub)
        editSub.setText(Prefs.autoStoreSubfolder(this))
        findViewById<Button>(R.id.btnSaveSub).setOnClickListener {
            val raw = editSub.text.toString().trim()
            val v = if (raw.isEmpty()) "" else Util.safeRelPath(raw)
            Prefs.setAutoStoreSubfolder(this, v)
            editSub.setText(v)
            toast(if (v.isEmpty()) "Files go directly into the receive folder" else "Files go into “$v” on the receiving device")
        }

        val editTypes = findViewById<EditText>(R.id.editAutoTypes)
        editTypes.setText(Prefs.autoTypes(this))
        findViewById<Button>(R.id.btnSaveTypes).setOnClickListener {
            val v = AutoSend.parseTypes(editTypes.text.toString()).joinToString(", ")
            Prefs.setAutoTypes(this, v)
            editTypes.setText(v)
            AutoSend.configChanged()
            toast(if (v.isEmpty()) "All file types" else "File types: $v")
        }

        val editDelay = findViewById<EditText>(R.id.editAutoDelay)
        editDelay.setText(Prefs.autoDelaySec(this).toString())
        findViewById<Button>(R.id.btnSaveDelay).setOnClickListener {
            val n = editDelay.text.toString().trim().toIntOrNull()
            if (n == null || n < 1 || n > 600) {
                toast("Enter a number from 1 to 600")
            } else {
                Prefs.setAutoDelaySec(this, n)
                toast("Files are sent $n s after the last save")
            }
        }

        // ---------- daily move ----------
        val swMove = findViewById<SwitchCompat>(R.id.switchMove)
        swMove.isChecked = Prefs.moveEnabled(this)
        swMove.setOnCheckedChangeListener { _, on ->
            Prefs.setMoveEnabled(this, on)
            if (on) {
                TransferService.start(this)
                if (Prefs.moveFrom(this) == null || Prefs.moveTo(this) == null) toast("Now choose both folders")
            }
        }
        findViewById<Button>(R.id.btnMoveFrom).setOnClickListener { pick("from", Prefs.moveFrom(this)) }
        findViewById<Button>(R.id.btnMoveTo).setOnClickListener { pick("to", Prefs.moveTo(this)) }
        findViewById<Button>(R.id.btnCloseDay).setOnClickListener { confirmCloseDay() }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("pickFor", pickFor)
    }

    override fun onResume() {
        super.onResume()
        if (Prefs.autoSendEnabled(this) || Prefs.moveEnabled(this)) TransferService.start(this)
        render()
        Hub.main.removeCallbacks(ticker)
        Hub.main.postDelayed(ticker, 1000)
    }

    override fun onPause() {
        super.onPause()
        Hub.main.removeCallbacks(ticker)
    }

    // ---------- folders ----------

    private fun pick(kind: String, start: String?) {
        pickFor = kind
        val i = Intent(this, FolderPickerActivity::class.java).putExtra(FolderPickerActivity.EXTRA_CHOOSE, true)
        if (start != null) i.putExtra(FolderPickerActivity.EXTRA_START, start)
        pickFolder.launch(i)
    }

    private fun onPicked(kind: String, path: String) {
        val p = File(path).absolutePath
        when (kind) {
            "watch" -> {
                val recv = Prefs.receiveDir(this).absolutePath
                if (AutoSend.isInside(p, recv)) {
                    toast("That is LanShare's receive folder — choose another one")
                    return
                }
                val cur = Prefs.autoFolders(this)
                val covering = cur.firstOrNull { AutoSend.isInside(p, it) }
                if (covering != null) {
                    toast("Already watched (${File(covering).name})")
                    return
                }
                val inside = cur.filter { AutoSend.isInside(it, p) }.toSet()
                Prefs.setAutoFolders(this, (cur - inside) + p)
                AutoSend.configChanged()
                toast("Watching “${File(p).name}”")
            }
            "from" -> {
                if (p == Prefs.moveTo(this)) {
                    toast("“Move from” and “Move to” must be different folders")
                    return
                }
                Prefs.setMoveFrom(this, p)
            }
            "to" -> {
                if (p == Prefs.moveFrom(this)) {
                    toast("“Move from” and “Move to” must be different folders")
                    return
                }
                Prefs.setMoveTo(this, p)
            }
        }
        render()
    }

    private fun confirmCloseDay() {
        if (Prefs.moveFrom(this) == null || Prefs.moveTo(this) == null) {
            toast("Choose “Move from” and “Move to” first")
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Close day now?")
            .setMessage(
                "All files in “${File(Prefs.moveFrom(this)!!).name}” will be moved to " +
                    "“${File(Prefs.moveTo(this)!!).name}”, including today's.\n\n" +
                    "Close any prescription that is open in Write first."
            )
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Move now") { _, _ ->
                val app = applicationContext
                Work.run {
                    val msg = AutoSend.closeDayNow(app)
                    Hub.main.post {
                        app.toast(msg)
                        if (!isFinishing) renderStatus()
                    }
                }
            }
            .show()
    }

    // ---------- drawing ----------

    @Suppress("DEPRECATION")
    private fun shortPath(p: String): String {
        val root = Environment.getExternalStorageDirectory().absolutePath
        return if (p.startsWith(root)) "Phone storage" + p.removePrefix(root) else p
    }

    private fun render() {
        val access = Util.hasStorageAccess(this)
        txtWarn.visibility = if (access) View.GONE else View.VISIBLE
        btnAllow.visibility = if (access) View.GONE else View.VISIBLE

        folderList.removeAllViews()
        val folders = Prefs.autoFolders(this).sorted()
        if (folders.isEmpty()) {
            val t = TextView(this)
            t.text = "No folder chosen yet."
            folderList.addView(t)
        }
        for (f in folders) {
            val row = LayoutInflater.from(this).inflate(R.layout.item_auto_folder, folderList, false)
            row.findViewById<TextView>(R.id.txtAutoFolder).text = shortPath(f)
            row.findViewById<Button>(R.id.btnAutoRemove).setOnClickListener {
                Prefs.setAutoFolders(this, Prefs.autoFolders(this) - f)
                AutoSend.configChanged()
                render()
            }
            folderList.addView(row)
        }

        renderTargets()
        txtFrom.text = Prefs.moveFrom(this)?.let { shortPath(it) } ?: "Not chosen"
        txtTo.text = Prefs.moveTo(this)?.let { shortPath(it) } ?: "Not chosen"
        renderStatus()
    }

    private fun renderTargets() {
        targetList.removeAllViews()
        val chosen = Prefs.autoTargets(this)
        val devices = LinkedHashMap<String, String>()
        for (d in Store.knownList()) devices[d.id] = d.name
        for (id in chosen) if (!devices.containsKey(id)) devices[id] = Hub.nameOf(id)
        devices.remove(Prefs.deviceId(this))
        txtNoTargets.visibility = if (devices.isEmpty()) View.VISIBLE else View.GONE
        for ((id, name) in devices.entries.sortedBy { it.value.lowercase() }) {
            val cb = MaterialCheckBox(this)
            val state = when (Hub.stateOf(id)) {
                Hub.ONLINE -> "online"
                Hub.ASLEEP -> "screen off"
                else -> "not reachable now"
            }
            cb.text = "$name  ($state)"
            cb.isChecked = id in chosen
            cb.setOnCheckedChangeListener { _, on ->
                val cur = Prefs.autoTargets(this).toMutableSet()
                if (on) cur.add(id) else cur.remove(id)
                Prefs.setAutoTargets(this, cur)
                AutoSend.configChanged()
            }
            targetList.addView(cb)
        }
    }

    private fun renderStatus() {
        txtStatus.text = when {
            !TransferService.running -> "LanShare is stopped. Open the home screen to start it."
            AutoSend.statusText.isEmpty() -> "Starting…"
            else -> AutoSend.statusText
        }
        txtLog.text = AutoSend.logText.ifEmpty { "Nothing moved yet." }
        val lines = AutoSend.activityText.lines().filter { it.isNotBlank() }
        txtActivity.text = if (lines.isEmpty()) "Nothing yet." else lines.take(15).joinToString("\n")
    }
}

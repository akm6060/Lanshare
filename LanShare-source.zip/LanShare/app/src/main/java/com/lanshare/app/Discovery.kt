package com.lanshare.app

import android.content.Context
import android.net.wifi.WifiManager
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

/**
 * Finds other LanShare devices and keeps the list steady:
 *  - every 3 s: a broadcast "hello" (finds new devices) PLUS a direct "hello" to each
 *    known device (direct packets are not dropped by Wi-Fi power saving like broadcasts are);
 *  - if a device goes quiet, it is checked with a direct TCP "ping" before being shown as away.
 */
class Discovery(private val ctx: Context, private val tcpPort: Int) {
    companion object {
        @Volatile var current: Discovery? = null
    }

    @Volatile private var running = false
    @Volatile private var socket: DatagramSocket? = null
    private var lock: WifiManager.MulticastLock? = null
    private val myId = Prefs.deviceId(ctx)
    private val lastProbe = ConcurrentHashMap<String, Long>()

    fun start() {
        running = true
        current = this
        try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val l = wm.createMulticastLock("LanShare:discovery")
            l.setReferenceCounted(false)
            l.acquire()
            lock = l
        } catch (e: Exception) { }
        openSocket()
        thread(name = "lanshare-disc-rx", isDaemon = true) { rxLoop() }
        thread(name = "lanshare-disc-tx", isDaemon = true) { txLoop() }
        thread(name = "lanshare-disc-probe", isDaemon = true) { probeLoop() }
    }

    fun stop() {
        running = false
        if (current === this) current = null
        val s = socket
        thread(isDaemon = true) {
            announce("bye")
            try { s?.close() } catch (e: Exception) { }
        }
        try { lock?.release() } catch (e: Exception) { }
    }

    /** Refresh button: shout again and check every known device directly. */
    fun announceAsync() {
        thread(isDaemon = true) {
            announce("hello")
            for (p in Hub.discovered.values.toList()) probe(p)
        }
    }

    private fun openSocket(): DatagramSocket? = try {
        val s = DatagramSocket(null)
        s.reuseAddress = true
        s.broadcast = true
        s.bind(InetSocketAddress(Proto.UDP_PORT))
        socket = s
        s
    } catch (e: Exception) { null }

    private fun message(type: String): ByteArray = JSONObject()
        .put("t", type)
        .put("id", myId)
        .put("name", Prefs.deviceName(ctx))
        .put("port", tcpPort)
        .put("v", Proto.VERSION)
        .toString().toByteArray(Charsets.UTF_8)

    private fun send(data: ByteArray, addr: InetAddress) {
        val s = socket ?: return
        try { s.send(DatagramPacket(data, data.size, addr, Proto.UDP_PORT)) } catch (e: Exception) { }
    }

    private fun announce(type: String) {
        val data = message(type)
        for (a in Util.broadcastAddresses()) send(data, a)
        // direct copies to devices we already know
        val now = System.currentTimeMillis()
        for (p in Hub.discovered.values) {
            if (now - p.lastSeen < Hub.ASLEEP_MS) {
                try { send(data, InetAddress.getByName(p.ip)) } catch (e: Exception) { }
            }
        }
    }

    private fun txLoop() {
        while (running) {
            announce("hello")
            try { Thread.sleep(3000) } catch (e: InterruptedException) { return }
        }
    }

    private fun probeLoop() {
        while (running) {
            try { Thread.sleep(4000) } catch (e: InterruptedException) { return }
            val now = System.currentTimeMillis()
            for (p in Hub.discovered.values.toList()) {
                val age = now - p.lastSeen
                if (age < 7_000L || age >= Hub.ASLEEP_MS) continue
                // quiet for a short while: check often; long asleep: check every 30 s
                val interval = 4_000L
                val last = lastProbe[p.id] ?: 0L
                if (now - last < interval) continue
                lastProbe[p.id] = now
                probe(p)
            }
        }
    }

    /** Direct TCP check. Returns true if the device answered. */
    private fun probe(p: Peer): Boolean = try {
        Socket().use { s ->
            s.connect(InetSocketAddress(p.ip, p.port), 2500)
            s.soTimeout = 4000
            val out = DataOutputStream(s.getOutputStream())
            val inp = DataInputStream(s.getInputStream())
            Proto.writeMsg(
                out, JSONObject().put("type", "ping").put("id", myId)
                    .put("name", Prefs.deviceName(ctx)).put("port", tcpPort)
            )
            val r = Proto.readMsg(inp)
            if (r.optString("type") == "pong" && r.optString("id") == p.id) {
                Hub.touch(p.id)
                true
            } else {
                false
            }
        }
    } catch (e: Exception) { false }

    private fun rxLoop() {
        val buf = ByteArray(4096)
        while (running) {
            val s = socket ?: openSocket()
            if (s == null) {
                try { Thread.sleep(2000) } catch (e: InterruptedException) { return }
                continue
            }
            try {
                val p = DatagramPacket(buf, buf.size)
                s.receive(p)
                handle(p)
            } catch (e: Exception) {
                if (!running) return
                if (s.isClosed) socket = null
            }
        }
    }

    private fun handle(p: DatagramPacket) {
        val o = try {
            JSONObject(String(p.data, 0, p.length, Charsets.UTF_8))
        } catch (e: Exception) { return }
        val id = o.optString("id")
        if (id.isEmpty() || id == myId) return
        val type = o.optString("t")
        if (type == "bye") {
            Hub.discovered.remove(id)
            Hub.notifyChanged()
            return
        }
        if (type != "hello" && type != "reply") return
        val addr = p.address ?: return
        val ip = addr.hostAddress ?: return
        val wasOnline = Hub.onlinePeer(id) != null
        Hub.seen(id, o.optString("name", "Unknown device"), ip, o.optInt("port", Proto.TCP_PORT))
        if (!wasOnline && type == "hello") send(message("reply"), addr)
    }
}

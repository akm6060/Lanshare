package com.lanshare.app

import android.content.Context
import android.net.wifi.WifiManager
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import kotlin.concurrent.thread

/**
 * Finds other LanShare devices: every 3 s each device broadcasts a small
 * "hello" UDP packet on the local network; new devices get an instant reply.
 */
class Discovery(private val ctx: Context, private val tcpPort: Int) {
    companion object {
        @Volatile var current: Discovery? = null
    }

    @Volatile private var running = false
    @Volatile private var socket: DatagramSocket? = null
    private var lock: WifiManager.MulticastLock? = null
    private val myId = Prefs.deviceId(ctx)

    fun start() {
        running = true
        current = this
        try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val l = wm.createMulticastLock("LanShare:discovery")
            l.setReferenceCounted(false)
            l.acquire()
            lock = l
        } catch (e: Exception) { }
        openSocket()
        thread(name = "lanshare-disc-rx", isDaemon = true) { rxLoop() }
        thread(name = "lanshare-disc-tx", isDaemon = true) { txLoop() }
    }

    fun stop() {
        running = false
        if (current === this) current = null
        val s = socket
        thread(isDaemon = true) {
            announce("bye")
            try { s?.close() } catch (e: Exception) { }
        }
        try { lock?.release() } catch (e: Exception) { }
    }

    fun announceAsync() {
        thread(isDaemon = true) { announce("hello") }
    }

    private fun openSocket(): DatagramSocket? = try {
        val s = DatagramSocket(null)
        s.reuseAddress = true
        s.broadcast = true
        s.bind(InetSocketAddress(Proto.UDP_PORT))
        socket = s
        s
    } catch (e: Exception) { null }

    private fun message(type: String): ByteArray = JSONObject()
        .put("t", type)
        .put("id", myId)
        .put("name", Prefs.deviceName(ctx))
        .put("port", tcpPort)
        .put("v", Proto.VERSION)
        .toString().toByteArray(Charsets.UTF_8)

    private fun send(data: ByteArray, addr: InetAddress) {
        val s = socket ?: return
        try { s.send(DatagramPacket(data, data.size, addr, Proto.UDP_PORT)) } catch (e: Exception) { }
    }

    private fun announce(type: String) {
        val data = message(type)
        for (a in Util.broadcastAddresses()) send(data, a)
    }

    private fun txLoop() {
        while (running) {
            announce("hello")
            try { Thread.sleep(3000) } catch (e: InterruptedException) { return }
        }
    }

    private fun rxLoop() {
        val buf = ByteArray(4096)
        while (running) {
            val s = socket ?: openSocket()
            if (s == null) {
                try { Thread.sleep(2000) } catch (e: InterruptedException) { return }
                continue
            }
            try {
                val p = DatagramPacket(buf, buf.size)
                s.receive(p)
                handle(p)
            } catch (e: Exception) {
                if (!running) return
                if (s.isClosed) socket = null
            }
        }
    }

    private fun handle(p: DatagramPacket) {
        val o = try {
            JSONObject(String(p.data, 0, p.length, Charsets.UTF_8))
        } catch (e: Exception) { return }
        val id = o.optString("id")
        if (id.isEmpty() || id == myId) return
        val type = o.optString("t")
        if (type == "bye") {
            Hub.discovered.remove(id)
            Hub.notifyChanged()
            return
        }
        if (type != "hello" && type != "reply") return
        val addr = p.address ?: return
        val ip = addr.hostAddress ?: return
        val name = o.optString("name", "Unknown device")
        val isNew = Hub.onlinePeer(id) == null
        val old = Hub.discovered[id]
        Hub.discovered[id] = Peer(id, name, ip, o.optInt("port", Proto.TCP_PORT), System.currentTimeMillis())
        Store.remember(id, name)
        if (isNew || old == null || old.name != name || old.ip != ip) Hub.notifyChanged()
        if (isNew && type == "hello") send(message("reply"), addr)
    }
}

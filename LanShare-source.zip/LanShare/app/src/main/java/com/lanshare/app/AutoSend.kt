package com.lanshare.app

import android.content.Context
import android.net.Uri
import android.os.FileObserver
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * AUTO-SEND: watches the chosen folders and sends every file that is created or edited to the
 * chosen devices, a few seconds after it was last saved. Replaces the auto-clicker.
 *
 * DAILY MOVE: files last changed before today are moved from one folder to another
 * (shortly after midnight, or as soon as LanShare runs if the tablet was off).
 *
 * Rules
 *  - A file is identified by its NAME (prescriptions are named after the patient), so a file
 *    moved from the Write folder to the backup folder is NOT sent again.
 *  - Stylus Labs Write documents (.html) keep the page number, scroll position and a preview
 *    picture inside the file. Those parts are ignored, so just opening and scrolling an old
 *    prescription does not send it. Only a change to the handwriting does.
 *  - Files already in a folder when it is added (or when auto-send is switched on) are not sent.
 *  - The file is copied first and the copy is sent, so the original can be edited/moved meanwhile.
 *  - If a receiving device is away, the file waits and goes as soon as the device is back.
 *    At the receiver, an edited prescription REPLACES the earlier copy.
 */
object AutoSend {
    private const val TAG = "LanShare"
    private const val TICK_MS = 1000L
    private const val FULL_SCAN_MS = 60_000L
    private const val MOVE_CHECK_MS = 60_000L
    private const val RETRY_MS = 20_000L
    private const val OFFLINE_NOTE_AFTER_MS = 60_000L
    private const val OFFLINE_NOTE_EVERY_MS = 10 * 60_000L
    private const val SNAPSHOT_CLEAN_EVERY_MS = 10 * 60_000L
    private const val SNAPSHOT_MIN_AGE_MS = 10 * 60_000L
    private const val MAX_DEPTH = 4
    private const val LOG_MAX = 30
    private const val STATE_FILE = "autosend.json"

    /** Write's settings block (page number, scroll position…) — not part of the prescription. */
    private val WRITE_CONFIG = Regex(
        "<script[^>]*text/writeconfig[^>]*>.*?</script>",
        setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
    )

    /** Write's hidden preview picture — changes when you scroll, not when you write. */
    private val WRITE_THUMB = Regex("\\s*<img[^>]*id=['\"]thumbnail['\"][^>]*>", RegexOption.IGNORE_CASE)

    private val MASK = FileObserver.CLOSE_WRITE or FileObserver.MOVED_TO or
        FileObserver.CREATE or FileObserver.MODIFY

    /** What we last read from a file: its size/date and the fingerprint of its content. */
    private class Entry(val size: Long, val mtime: Long, val hash: String, var snapshot: String?)

    /** A file that changed recently; it is handled once it has been quiet for a few seconds. */
    private class Dirty(var size: Long, var mtime: Long, var since: Long)

    private val lock = Any()
    private lateinit var app: Context
    private var loaded = false

    // ---- saved between restarts ----
    private val cache = HashMap<String, Entry>()                    // file path -> Entry
    private val sent = HashMap<String, HashMap<String, String>>()   // device id -> (file name -> fingerprint)
    private val baselinedFolders = HashSet<String>()
    private val baselinedDevices = HashSet<String>()
    private var fullBaseline = false
    private val log = ArrayList<String>()                           // newest first
    private var lastSent = ""

    // ---- live ----
    private val dirty = HashMap<String, Dirty>()
    private val pending = LinkedHashSet<String>()      // paths that still need sending somewhere
    private val inFlight = HashSet<String>()           // "deviceId|name"
    private val lastAttempt = HashMap<String, Long>()
    private val waitingSince = HashMap<String, Long>() // "deviceId|name" -> device away since
    private val notifiedNotMoved = HashSet<String>()
    private var notifiedDay = 0L
    private val observers = HashMap<String, FileObserver>()
    private val events = ConcurrentLinkedQueue<String>()
    private var curFolders: List<String> = emptyList()
    private var curTypes: Set<String> = emptySet()
    private var curRecv = ""
    private var lastFull = 0L
    private var lastMoveCheck = 0L
    private var lastSave = 0L
    private var lastSnapshotClean = 0L
    private var lastOfflineNote = 0L
    private var changed = false

    @Volatile private var rescan = true
    @Volatile private var running = false
    @Volatile private var generation = 0

    /** Read by the settings screen (never blocks the UI). */
    @Volatile var statusText: String = ""
        private set
    @Volatile var logText: String = ""
        private set

    // =====================================================================
    // lifecycle
    // =====================================================================

    fun init(ctx: Context) {
        synchronized(lock) {
            if (loaded) return
            app = ctx.applicationContext
            load()
            loaded = true
        }
    }

    /** Called by TransferService (runs as long as LanShare is ready to receive). */
    fun start(ctx: Context) {
        init(ctx)
        synchronized(lock) {
            if (running) return
            running = true
            rescan = true
            val gen = ++generation
            val t = Thread({ runLoop(gen) }, "lanshare-autosend")
            t.isDaemon = true
            t.start()
        }
    }

    fun stop() {
        synchronized(lock) {
            running = false
            generation++
            stopObservers()
            if (loaded && changed) save()
        }
    }

    /** Folders, devices or file types changed in settings. */
    fun configChanged() {
        rescan = true
    }

    private fun runLoop(gen: Int) {
        while (running && gen == generation) {
            try {
                synchronized(lock) { tick() }
            } catch (t: Throwable) {
                Log.e(TAG, "Auto-send problem", t)
            }
            try {
                Thread.sleep(TICK_MS)
            } catch (e: InterruptedException) {
                break
            }
        }
    }

    // =====================================================================
    // main loop (always holding [lock])
    // =====================================================================

    private fun tick() {
        val now = System.currentTimeMillis()
        val access = Util.hasStorageAccess(app)
        val autoOn = access && Prefs.autoSendEnabled(app)
        val moveOn = access && Prefs.moveEnabled(app)

        if (Prefs.takeAutoRebaseline(app)) {
            fullBaseline = true
            rescan = true
            changed = true
        }

        curRecv = Prefs.receiveDir(app).absolutePath
        curTypes = parseTypes(Prefs.autoTypes(app))
        curFolders = if (autoOn) watchFolders() else emptyList()
        val targets = if (autoOn) Prefs.autoTargets(app).filter { it != Prefs.deviceId(app) } else emptyList()

        if (autoOn) {
            drainEvents(now)
            if (rescan || now - lastFull >= FULL_SCAN_MS) {
                rescan = false
                lastFull = now
                fullScan(curFolders, targets, now)
            }
            processDirty(now)
            sendPending(now, targets)
        } else {
            stopObservers()
            events.clear()
            dirty.clear()
            pending.clear()
            waitingSince.clear()
        }

        if (moveOn && now - lastMoveCheck >= MOVE_CHECK_MS) {
            lastMoveCheck = now
            moveFiles(manual = false)
        }
        if (now - lastSnapshotClean >= SNAPSHOT_CLEAN_EVERY_MS) {
            lastSnapshotClean = now
            cleanSnapshots(now)
        }
        if (changed && now - lastSave >= 2000) {
            save()
            lastSave = now
        }
        updateStatus(access, curFolders, targets)
    }

    // =====================================================================
    // finding changed files
    // =====================================================================

    private fun watchFolders(): List<String> =
        Prefs.autoFolders(app)
            .map { File(it).absolutePath }
            .filter { File(it).isDirectory && !isInside(it, curRecv) }
            .distinct()
            .sorted()

    fun isInside(path: String, dir: String): Boolean = path == dir || path.startsWith("$dir/")

    fun parseTypes(s: String): Set<String> =
        s.split(',', ';', ' ')
            .map { it.trim().removePrefix(".").lowercase(Locale.ROOT) }
            .filter { it.isNotEmpty() }
            .toSet()

    private fun acceptedName(name: String, types: Set<String>): Boolean {
        if (name.startsWith(".") || name.endsWith("~")) return false
        val lower = name.lowercase(Locale.ROOT)
        if (lower == "autosave.html" || lower.endsWith(".tmp") || lower.endsWith(".part")) return false
        if (types.isEmpty()) return true
        val dot = lower.lastIndexOf('.')
        return dot > 0 && lower.substring(dot + 1) in types
    }

    /** Should a path reported by the folder watcher be handled? */
    private fun eligible(path: String): Boolean {
        val root = curFolders.firstOrNull { path.startsWith("$it/") } ?: return false
        if (isInside(path, curRecv)) return false
        val parts = path.substring(root.length + 1).split('/')
        if (parts.size > MAX_DEPTH + 1) return false
        if (parts.any { it.isEmpty() || it.startsWith(".") }) return false
        return acceptedName(parts.last(), curTypes)
    }

    private fun drainEvents(now: Long) {
        while (true) {
            val p = events.poll() ?: break
            if (File(p).isDirectory) {
                rescan = true // a new sub-folder: watch it too
                continue
            }
            if (!eligible(p)) continue
            val d = dirty[p]
            if (d == null) dirty[p] = Dirty(-1, -1, now) else d.since = now
        }
    }

    private fun collect(dir: File, depth: Int, dirs: MutableList<String>, out: MutableList<File>) {
        dirs.add(dir.absolutePath)
        val list = dir.listFiles() ?: return
        for (f in list) {
            if (f.name.startsWith(".")) continue
            if (isInside(f.absolutePath, curRecv)) continue
            if (f.isDirectory) {
                if (depth < MAX_DEPTH) collect(f, depth + 1, dirs, out)
            } else if (acceptedName(f.name, curTypes)) {
                out.add(f)
            }
        }
    }

    /** Every minute (and after any settings change): catch anything the watcher missed. */
    private fun fullScan(folders: List<String>, targets: List<String>, now: Long) {
        val delay = Prefs.autoDelaySec(app) * 1000L
        val dirs = ArrayList<String>()
        val files = ArrayList<File>()
        for (root in folders) collect(File(root), 0, dirs, files)
        updateObservers(dirs)

        val full = fullBaseline
        val newFolders = folders.filter { it !in baselinedFolders }
        val newDevices = targets.filter { it !in baselinedDevices }
        val seen = HashSet<String>()

        for (f in files) {
            val path = f.absolutePath
            if (!seen.add(path)) continue
            val size = f.length()
            val mtime = f.lastModified()
            val name = f.name
            var e = cache[path]

            // Files that were already there before: count them as sent, don't flood the store.
            val inNewFolder = newFolders.any { isInside(path, it) }
            if (full || inNewFolder || newDevices.isNotEmpty()) {
                if (e == null || e.size != size || e.mtime != mtime) {
                    val h = fingerprint(f)
                    if (h != null) {
                        e = Entry(size, mtime, h, null)
                        cache[path] = e
                        changed = true
                    }
                }
                val base = e
                if (base != null) {
                    for (dev in targets) {
                        val m = sent.getOrPut(dev) { HashMap() }
                        if (full || dev in newDevices) m[name] = base.hash
                        else if (inNewFolder && !m.containsKey(name)) m[name] = base.hash
                    }
                    changed = true
                }
            }

            val cur = e
            if (cur == null || cur.size != size || cur.mtime != mtime) {
                if (path !in dirty) dirty[path] = Dirty(size, mtime, if (now - mtime >= delay) now - delay else now)
            } else if (targets.any { dev -> sent[dev]?.get(name) != cur.hash }) {
                pending.add(path)
            }
        }

        if (cache.keys.retainAll(seen)) changed = true
        pending.retainAll(seen)
        // "Switched on" only counts once there is something to watch and someone to send to.
        val consumeFull = full && folders.isNotEmpty() && targets.isNotEmpty()
        if (consumeFull || baselinedFolders != folders.toSet() || baselinedDevices != targets.toSet()) {
            baselinedFolders.clear()
            baselinedFolders.addAll(folders)
            baselinedDevices.clear()
            baselinedDevices.addAll(targets)
            if (consumeFull) fullBaseline = false
            changed = true
        }
    }

    /** A file is "saved" once its size and date have not changed for the chosen number of seconds. */
    private fun processDirty(now: Long) {
        if (dirty.isEmpty()) return
        val delay = Prefs.autoDelaySec(app) * 1000L
        val ready = ArrayList<String>()
        val iter = dirty.entries.iterator()
        while (iter.hasNext()) {
            val en = iter.next()
            val d = en.value
            val f = File(en.key)
            if (!f.isFile) {
                iter.remove()
                continue
            }
            val size = f.length()
            val mtime = f.lastModified()
            if (d.size == -1L) {
                d.size = size
                d.mtime = mtime
            } else if (size != d.size || mtime != d.mtime) {
                d.size = size
                d.mtime = mtime
                d.since = now
                continue
            }
            if (now - d.since < delay) continue
            iter.remove()
            ready.add(en.key)
        }
        for (path in ready) onSaved(path, now)
    }

    private fun onSaved(path: String, now: Long) {
        val src = File(path)
        val size = src.length()
        val mtime = src.lastModified()
        val e = cache[path]
        if (e == null || e.size != size || e.mtime != mtime) {
            val snap = makeSnapshot(src)
            if (snap == null) {
                dirty[path] = Dirty(-1, -1, now + RETRY_MS) // try again a bit later
                return
            }
            if (src.length() != size || src.lastModified() != mtime) {
                snap.parentFile?.deleteRecursively() // saved again while copying: wait for it
                dirty[path] = Dirty(-1, -1, now)
                return
            }
            val h = fingerprint(snap) ?: return
            cache[path] = Entry(size, mtime, h, snap.absolutePath)
            changed = true
        }
        pending.add(path)
    }

    // =====================================================================
    // sending
    // =====================================================================

    private fun sendPending(now: Long, targets: List<String>) {
        val away = HashSet<String>()
        val iter = pending.iterator()
        while (iter.hasNext()) {
            val path = iter.next()
            val e = cache[path]
            if (e == null) {
                iter.remove()
                continue
            }
            val name = File(path).name
            val need = targets.filter { dev -> sent[dev]?.get(name) != e.hash }
            if (need.isEmpty()) {
                iter.remove()
                continue
            }
            for (dev in need) {
                val key = "$dev|$name"
                if (key in inFlight) continue
                if (Hub.reachablePeer(dev) == null) {
                    away.add(key)
                    continue
                }
                if (now - (lastAttempt[key] ?: 0L) < RETRY_MS) continue
                val snap = ensureSnapshot(path, e) ?: continue
                lastAttempt[key] = now
                inFlight.add(key)
                launchSend(dev, path, name, e.hash, snap, e.mtime, key)
            }
        }
        for (k in away) if (!waitingSince.containsKey(k)) waitingSince[k] = now // (putIfAbsent needs Android 7+)
        waitingSince.keys.retainAll(away)

        val longWaiting = waitingSince.filterValues { now - it >= OFFLINE_NOTE_AFTER_MS }
        if (longWaiting.isNotEmpty() && now - lastOfflineNote >= OFFLINE_NOTE_EVERY_MS) {
            lastOfflineNote = now
            val names = longWaiting.keys.map { Hub.nameOf(it.substringBefore('|')) }.distinct().joinToString(", ")
            val n = longWaiting.size
            Notif.event(
                app, "$names is not reachable",
                "$n file" + (if (n == 1) " is" else "s are") +
                    " waiting. They will be sent automatically when $names is back on the Wi-Fi."
            )
        }
    }

    private fun launchSend(
        dev: String, path: String, name: String, hash: String, snap: File, mtime: Long, key: String
    ) {
        val sub = Prefs.autoStoreSubfolder(app).trim()
        val rel = Util.safeRelPath(if (sub.isEmpty()) name else "$sub/$name")
        val item = SendItem(Uri.fromFile(snap), rel, snap.length(), mtime)
        val historyId = "auto-" + Proto.sha1Hex("$dev|$name|$hash")
        val title = name.substringBeforeLast('.').ifEmpty { name }
        val ctx = app
        Work.run {
            var ok = false
            try {
                ok = Sender.sendFiles(ctx, dev, listOf(item), title, historyId, auto = true, sourcePaths = listOf(path))
            } finally {
                synchronized(lock) {
                    inFlight.remove(key)
                    if (ok) {
                        sent.getOrPut(dev) { HashMap() }[name] = hash
                        lastAttempt.remove(key)
                        waitingSince.remove(key)
                        lastSent = "$title → ${Hub.nameOf(dev)}, ${clock(System.currentTimeMillis())}"
                        changed = true
                    }
                }
            }
        }
    }

    private fun snapshotRoot() = File(app.cacheDir, "autosend")

    /** Copy of the file as it was when saved; this copy is what gets sent. */
    private fun makeSnapshot(src: File): File? = try {
        val dir = File(snapshotRoot(), System.nanoTime().toString())
        dir.mkdirs()
        val dst = File(dir, src.name)
        src.inputStream().use { i -> dst.outputStream().use { o -> i.copyTo(o, 256 * 1024) } }
        dst.setLastModified(src.lastModified())
        dst
    } catch (e: Exception) {
        Log.w(TAG, "Auto-send can't read ${src.name}: ${e.message}")
        null
    }

    private fun ensureSnapshot(path: String, e: Entry): File? {
        e.snapshot?.let { val f = File(it); if (f.isFile) return f }
        val src = File(path)
        if (!src.isFile || src.length() != e.size || src.lastModified() != e.mtime) {
            dirty[path] = Dirty(-1, -1, System.currentTimeMillis())
            return null
        }
        val snap = makeSnapshot(src) ?: return null
        e.snapshot = snap.absolutePath
        changed = true
        return snap
    }

    /** Copies are only kept while something still has to be sent. */
    private fun cleanSnapshots(now: Long) {
        val keep = HashSet<String>()
        for (p in pending) cache[p]?.snapshot?.let { s -> File(s).parentFile?.absolutePath?.let { keep.add(it) } }
        snapshotRoot().listFiles()?.forEach { d ->
            if (d.absolutePath !in keep && now - d.lastModified() > SNAPSHOT_MIN_AGE_MS) d.deleteRecursively()
        }
        for (e in cache.values) {
            val s = e.snapshot ?: continue
            if (!File(s).exists()) e.snapshot = null
        }
    }

    /** Fingerprint of what matters in the file (for Write: the handwriting only). */
    private fun fingerprint(f: File): String? = try {
        val md = MessageDigest.getInstance("SHA-256")
        val lower = f.name.lowercase(Locale.ROOT)
        if ((lower.endsWith(".html") || lower.endsWith(".htm")) && f.length() < 64L * 1024 * 1024) {
            var s = f.readText(Charsets.ISO_8859_1)
            s = WRITE_CONFIG.replace(s, "")
            s = WRITE_THUMB.replace(s, "")
            md.update(s.toByteArray(Charsets.ISO_8859_1))
        } else {
            f.inputStream().use { ins ->
                val buf = ByteArray(256 * 1024)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    md.update(buf, 0, n)
                }
            }
        }
        md.digest().joinToString("") { "%02x".format(it) }.take(32)
    } catch (e: Exception) {
        Log.w(TAG, "Auto-send can't read ${f.name}: ${e.message}")
        null
    }

    // =====================================================================
    // folder watcher
    // =====================================================================

    @Suppress("DEPRECATION")
    private fun updateObservers(dirs: List<String>) {
        val want = dirs.toSet()
        val iter = observers.entries.iterator()
        while (iter.hasNext()) {
            val en = iter.next()
            if (en.key !in want) {
                en.value.stopWatching()
                iter.remove()
            }
        }
        for (d in want) {
            if (observers.containsKey(d)) continue
            val o = object : FileObserver(d, MASK) {
                override fun onEvent(event: Int, path: String?) {
                    if (path != null) events.add("$d/$path")
                }
            }
            try {
                o.startWatching()
                observers[d] = o
            } catch (e: Exception) {
                Log.w(TAG, "Can't watch $d: ${e.message}")
            }
        }
    }

    private fun stopObservers() {
        for (o in observers.values) {
            try { o.stopWatching() } catch (e: Exception) { }
        }
        observers.clear()
    }

    /**
     * A file that is no longer where History remembers it (e.g. moved to the backup folder
     * at night): look for the same name in the auto-send and daily-move folders.
     */
    fun findByName(ctx: Context, name: String): File? {
        val dirs = LinkedHashSet<String>()
        Prefs.moveTo(ctx)?.let { dirs.add(it) }
        Prefs.moveFrom(ctx)?.let { dirs.add(it) }
        dirs.addAll(Prefs.autoFolders(ctx))
        for (d in dirs) {
            val f = File(d, name)
            if (f.isFile) return f
        }
        for (d in dirs) {
            val found = File(d).walkTopDown().maxDepth(MAX_DEPTH + 1)
                .onEnter { !it.name.startsWith(".") }
                .firstOrNull { it.isFile && it.name == name }
            if (found != null) return found
        }
        return null
    }

    // =====================================================================
    // daily move
    // =====================================================================

    /** "Close day now": moves today's files too. Runs on a background thread. */
    fun closeDayNow(ctx: Context): String {
        init(ctx)
        synchronized(lock) { return moveFiles(manual = true) }
    }

    private fun startOfToday(now: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = now
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun moveFiles(manual: Boolean): String {
        if (!Util.hasStorageAccess(app)) return "File access is not allowed"
        val fromPath = Prefs.moveFrom(app)
        val toPath = Prefs.moveTo(app)
        if (fromPath == null || toPath == null) return "Choose both folders first"
        val from = File(fromPath)
        val to = File(toPath)
        if (!from.isDirectory) return "Folder not found: $fromPath"
        if (!to.isDirectory) return "Folder not found: $toPath"
        if (from.absolutePath == to.absolutePath) return "The two folders are the same"

        val types = parseTypes(Prefs.autoTypes(app))
        val now = System.currentTimeMillis()
        val today = startOfToday(now)
        if (today != notifiedDay) {
            notifiedNotMoved.clear()
            notifiedDay = today
        }
        // Daily: only files last changed before today. Close day: everything not saved in the last 10 s.
        val cutoff = if (manual) now - 10_000 else today
        val files = (from.listFiles() ?: emptyArray()).filter {
            it.isFile && acceptedName(it.name, types) && it.lastModified() < cutoff && it.absolutePath !in dirty
        }.sortedBy { it.name.lowercase(Locale.ROOT) }

        var moved = 0
        val sameName = ArrayList<String>()
        val failed = ArrayList<String>()
        for (f in files) {
            val dest = File(to, f.name)
            if (dest.exists()) {
                sameName.add(f.name)
                continue
            }
            val oldPath = f.absolutePath
            val e = cache[oldPath]
            if (moveOne(f, dest)) {
                moved++
                cache.remove(oldPath)
                if (e != null && dest.length() == e.size && dest.lastModified() == e.mtime) {
                    cache[dest.absolutePath] = e
                }
                if (pending.remove(oldPath)) pending.add(dest.absolutePath)
                changed = true
            } else {
                failed.add(f.name)
            }
        }

        val parts = ArrayList<String>()
        if (moved > 0) parts.add("Moved $moved file" + (if (moved == 1) "" else "s") + " to ${to.name}")
        if (sameName.isNotEmpty()) {
            parts.add("Not moved, same name already in ${to.name}: " + sameName.joinToString(", "))
        }
        if (failed.isNotEmpty()) parts.add("Could not be moved: " + failed.joinToString(", "))
        val msg = if (parts.isEmpty()) "Nothing to move" else parts.joinToString("\n")

        val fresh = (sameName + failed).filter { notifiedNotMoved.add(it) }
        if (manual || moved > 0 || fresh.isNotEmpty()) {
            addLog((if (manual) "Close day — " else "Daily move — ") + msg)
        }
        if (!manual && fresh.isNotEmpty()) {
            Notif.event(
                app, "Daily move: " + fresh.size + " file" + (if (fresh.size == 1) "" else "s") + " not moved",
                msg + "\nRename and they will be moved at the next check."
            )
        }
        return msg
    }

    private fun moveOne(src: File, dest: File): Boolean {
        if (src.renameTo(dest)) return true
        return try {
            val mtime = src.lastModified()
            src.inputStream().use { i -> dest.outputStream().use { o -> i.copyTo(o, 256 * 1024) } }
            dest.setLastModified(mtime)
            if (dest.length() == src.length() && src.delete()) true
            else {
                dest.delete()
                false
            }
        } catch (e: Exception) {
            dest.delete()
            false
        }
    }

    // =====================================================================
    // status, log, saving
    // =====================================================================

    private fun clock(ms: Long): String = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(ms))

    private fun addLog(line: String) {
        log.add(0, clock(System.currentTimeMillis()) + " — " + line)
        while (log.size > LOG_MAX) log.removeAt(log.size - 1)
        logText = log.joinToString("\n\n")
        changed = true
    }

    private fun updateStatus(access: Boolean, folders: List<String>, targets: List<String>) {
        val sb = StringBuilder()
        if (!access) sb.append("✗ File access is not allowed — auto-send and daily move are paused.\n")
        if (!Prefs.autoSendEnabled(app)) {
            sb.append("Auto-send is off.")
        } else if (folders.isEmpty()) {
            sb.append("Auto-send: choose at least one folder.")
        } else if (targets.isEmpty()) {
            sb.append("Auto-send: tick the device(s) to send to.")
        } else {
            sb.append("✓ Auto-send is on → ").append(targets.joinToString(", ") { Hub.nameOf(it) })
            if (inFlight.isNotEmpty()) sb.append("\nSending ${inFlight.size} file(s)…")
            if (waitingSince.isNotEmpty()) {
                sb.append("\n${waitingSince.size} file(s) waiting — receiving device not reachable")
            }
            if (lastSent.isNotEmpty()) sb.append("\nLast sent: $lastSent")
        }
        statusText = sb.toString()
    }

    private fun save() {
        try {
            val o = JSONObject()
            val c = JSONObject()
            for ((p, e) in cache) c.put(p, JSONArray().put(e.size).put(e.mtime).put(e.hash).put(e.snapshot ?: ""))
            o.put("cache", c)
            val s = JSONObject()
            for ((dev, m) in sent) {
                val mo = JSONObject()
                for ((n, h) in m) mo.put(n, h)
                s.put(dev, mo)
            }
            o.put("sent", s)
            o.put("bf", JSONArray(baselinedFolders.toList()))
            o.put("bd", JSONArray(baselinedDevices.toList()))
            o.put("full", fullBaseline)
            o.put("log", JSONArray(log))
            o.put("last", lastSent)
            val text = o.toString()
            val target = File(app.filesDir, STATE_FILE)
            val tmp = File(app.filesDir, "$STATE_FILE.tmp")
            tmp.writeText(text)
            if (!tmp.renameTo(target)) {
                target.writeText(text)
                tmp.delete()
            }
            changed = false
        } catch (e: Exception) {
            Log.w(TAG, "Auto-send state not saved: ${e.message}")
        }
    }

    private fun load() {
        try {
            val f = File(app.filesDir, STATE_FILE)
            if (!f.isFile) return
            val o = JSONObject(f.readText())
            o.optJSONObject("cache")?.let { c ->
                for (p in c.keys()) {
                    val a = c.getJSONArray(p)
                    val snap = a.optString(3)
                    cache[p] = Entry(a.getLong(0), a.getLong(1), a.getString(2), snap.ifEmpty { null })
                }
            }
            o.optJSONObject("sent")?.let { s ->
                for (dev in s.keys()) {
                    val mo = s.getJSONObject(dev)
                    val m = HashMap<String, String>()
                    for (n in mo.keys()) m[n] = mo.getString(n)
                    sent[dev] = m
                }
            }
            o.optJSONArray("bf")?.let { a -> for (i in 0 until a.length()) baselinedFolders.add(a.getString(i)) }
            o.optJSONArray("bd")?.let { a -> for (i in 0 until a.length()) baselinedDevices.add(a.getString(i)) }
            fullBaseline = o.optBoolean("full")
            o.optJSONArray("log")?.let { a -> for (i in 0 until a.length()) log.add(a.getString(i)) }
            lastSent = o.optString("last")
            logText = log.joinToString("\n\n")
        } catch (e: Exception) {
            Log.w(TAG, "Auto-send state not loaded: ${e.message}")
        }
    }
}

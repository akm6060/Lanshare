package com.lanshare.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

/** Device list with tick boxes. Ticks are remembered (see Hub.isSelected). */
class DeviceAdapter(
    private val isSelected: (String) -> Boolean,
    private val onTap: (DeviceRow) -> Unit,
    private val onLongPress: (DeviceRow) -> Unit
) : RecyclerView.Adapter<DeviceAdapter.VH>() {
    private var rows: List<DeviceRow> = emptyList()
    private var signature = ""

    fun submit(r: List<DeviceRow>) {
        val sig = r.joinToString("|") { "${it.id},${it.name},${it.peer?.ip},${isSelected(it.id)}" }
        if (sig == signature) return
        signature = sig
        rows = r
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val chk: CheckBox = v.findViewById(R.id.chk)
        val name: TextView = v.findViewById(R.id.txtName)
        val sub: TextView = v.findViewById(R.id.txtSub)
        val dot: View = v.findViewById(R.id.dot)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_device, parent, false))

    override fun getItemCount(): Int = rows.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val r = rows[position]
        val peer = r.peer
        h.chk.isChecked = isSelected(r.id)
        h.name.text = r.name
        h.sub.text = if (peer != null) "Online • ${peer.ip}" else "Offline • long-press to forget"
        h.dot.setBackgroundResource(if (peer != null) R.drawable.dot_online else R.drawable.dot_offline)
        h.itemView.setOnClickListener { onTap(r) }
        h.itemView.setOnLongClickListener {
            onLongPress(r)
            true
        }
        h.itemView.alpha = if (peer == null) 0.6f else 1f
    }
}

class HistoryAdapter(
    private val onClick: (HistoryEntry) -> Unit,
    private val onRetry: (HistoryEntry) -> Unit
) : RecyclerView.Adapter<HistoryAdapter.VH>() {
    private var rows: List<HistoryEntry> = emptyList()

    fun submit(r: List<HistoryEntry>) {
        rows = r
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: TextView = v.findViewById(R.id.txtIcon)
        val title: TextView = v.findViewById(R.id.txtHTitle)
        val sub: TextView = v.findViewById(R.id.txtHSub)
        val status: TextView = v.findViewById(R.id.txtHStatus)
        val retry: Button = v.findViewById(R.id.btnRetry)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_history, parent, false))

    override fun getItemCount(): Int = rows.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val e = rows[position]
        val ctx = h.itemView.context
        h.icon.text = if (e.outgoing) "↑" else "↓"
        h.title.text = e.title
        val who = (if (e.outgoing) "To " else "From ") + e.deviceName
        val size = if (e.isText) "" else " • ${e.fileCount} file(s), ${Util.formatBytes(e.totalBytes)}"
        h.sub.text = "$who • ${Util.formatTime(e.time)}$size"
        val speed = if (e.avgSpeed > 0) " at ${Util.formatSpeed(e.avgSpeed)}" else ""
        h.status.text = when (e.status) {
            HistoryEntry.DONE -> "✓ Done$speed"
            HistoryEntry.FAILED -> "✗ Failed" + (e.error?.let { ": $it" } ?: "")
            HistoryEntry.CANCELLED -> "Cancelled"
            else -> "In progress…"
        }
        val color = when (e.status) {
            HistoryEntry.DONE -> R.color.ok
            HistoryEntry.FAILED -> R.color.bad
            else -> R.color.muted
        }
        h.status.setTextColor(ContextCompat.getColor(ctx, color))
        val canRetry = e.outgoing &&
            (e.status == HistoryEntry.FAILED || e.status == HistoryEntry.CANCELLED) &&
            (e.isText || e.items.isNotEmpty())
        h.retry.visibility = if (canRetry) View.VISIBLE else View.GONE
        h.retry.setOnClickListener { onRetry(e) }
        h.itemView.setOnClickListener { onClick(e) }
    }
}

/** Fills an item_transfer card with live progress. */
object TransferViews {
    fun bind(v: View, t: ActiveTransfer) {
        v.findViewById<TextView>(R.id.txtTitle).text =
            (if (t.outgoing) "↑ To " else "↓ From ") + t.deviceName + " — " + t.title
        val working = t.status == "Sending" || t.status == "Receiving"
        v.findViewById<TextView>(R.id.txtFile).text =
            if (working && t.currentFile.isNotEmpty()) "File ${minOf(t.filesDone + 1, t.fileCount)} of ${t.fileCount}: ${t.currentFile}"
            else t.status
        val pct = if (t.totalBytes > 0) (t.doneBytes * 1000 / t.totalBytes).toInt() else 0
        v.findViewById<ProgressBar>(R.id.progress).progress = pct
        val left = (t.totalBytes - t.doneBytes).coerceAtLeast(0)
        val eta = if (t.speed > 0) " • ${Util.formatEta(left / t.speed)} remaining" else ""
        v.findViewById<TextView>(R.id.txtStats).text =
            "${Util.formatBytes(t.doneBytes)} of ${Util.formatBytes(t.totalBytes)} (${pct / 10}%) • " +
                "${Util.formatBytes(left)} left\n${Util.formatSpeed(t.speed)}$eta"
        v.findViewById<Button>(R.id.btnCancel).setOnClickListener { Work.run { t.cancel() } }
    }
}

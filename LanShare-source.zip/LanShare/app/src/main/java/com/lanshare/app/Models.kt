package com.lanshare.app

import android.net.Uri
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject

data class SendItem(val uri: Uri, val relPath: String, val size: Long, val mtime: Long) {
    fun toJson(): JSONObject =
        JSONObject().put("u", uri.toString()).put("p", relPath).put("s", size).put("m", mtime)

    companion object {
        fun fromJson(o: JSONObject) =
            SendItem(Uri.parse(o.getString("u")), o.getString("p"), o.getLong("s"), o.optLong("m"))
    }
}

/** A LanShare device seen on the network before (kept so it still shows when offline). */
data class KnownDevice(val id: String, val name: String) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name)

    companion object {
        fun fromJson(o: JSONObject) = KnownDevice(o.getString("id"), o.optString("name", "Device"))
    }
}

/** A device currently announcing itself on the network. */
data class Peer(val id: String, val name: String, val ip: String, val port: Int, val lastSeen: Long)

/** One row on the device list. peer == null means offline. state = Hub.ONLINE / ASLEEP / OFFLINE. */
data class DeviceRow(val id: String, val name: String, val peer: Peer?, val state: Int)

class HistoryEntry(
    val id: String,
    var time: Long,
    val outgoing: Boolean,
    val deviceId: String,
    var deviceName: String,
    val title: String,
    val isText: Boolean,
    val fileCount: Int,
    val totalBytes: Long,
    var status: String,
    var avgSpeed: Long = 0,
    var error: String? = null,
    var text: String? = null,
    var items: List<SendItem> = emptyList()
) {
    fun toJson(): JSONObject {
        val o = JSONObject()
            .put("id", id).put("time", time).put("out", outgoing)
            .put("dev", deviceId).put("devName", deviceName).put("title", title)
            .put("isText", isText).put("count", fileCount).put("total", totalBytes)
            .put("status", status).put("speed", avgSpeed)
        error?.let { o.put("error", it) }
        text?.let { o.put("text", it) }
        if (items.isNotEmpty()) {
            val a = JSONArray()
            for (item in items) a.put(item.toJson())
            o.put("items", a)
        }
        return o
    }

    companion object {
        const val ACTIVE = "active"
        const val DONE = "done"
        const val FAILED = "failed"
        const val CANCELLED = "cancelled"

        fun fromJson(o: JSONObject): HistoryEntry {
            val list = ArrayList<SendItem>()
            val a = o.optJSONArray("items")
            if (a != null) for (i in 0 until a.length()) list.add(SendItem.fromJson(a.getJSONObject(i)))
            return HistoryEntry(
                id = o.getString("id"),
                time = o.optLong("time"),
                outgoing = o.optBoolean("out"),
                deviceId = o.optString("dev"),
                deviceName = o.optString("devName"),
                title = o.optString("title"),
                isText = o.optBoolean("isText"),
                fileCount = o.optInt("count"),
                totalBytes = o.optLong("total"),
                status = o.optString("status", FAILED),
                avgSpeed = o.optLong("speed"),
                error = if (o.has("error")) o.getString("error") else null,
                text = if (o.has("text")) o.getString("text") else null,
                items = list
            )
        }
    }
}

/** Live progress of one running transfer (shown with a progress bar). */
class ActiveTransfer(
    val id: String,
    val outgoing: Boolean,
    val deviceName: String,
    val title: String,
    val totalBytes: Long,
    val fileCount: Int
) {
    @Volatile var doneBytes = 0L
        private set
    @Volatile var filesDone = 0
    @Volatile var currentFile = ""
    @Volatile var speed = 0L
    @Volatile var status = "Connecting…"
    @Volatile var cancelled = false
    @Volatile var onCancel: (() -> Unit)? = null

    private var sampleTime = SystemClock.elapsedRealtime()
    private var sampleBytes = 0L
    private var sessionStart = SystemClock.elapsedRealtime()
    private var sessionStartBytes = 0L

    /** Bytes already present (resumed / skipped) when this attempt begins. */
    fun setStartBytes(b: Long) {
        doneBytes = b
        sampleBytes = b
        sessionStartBytes = b
        sampleTime = SystemClock.elapsedRealtime()
        sessionStart = sampleTime
        speed = 0
    }

    fun addBytes(n: Int) {
        doneBytes += n
        val now = SystemClock.elapsedRealtime()
        val dt = now - sampleTime
        if (dt >= 500) {
            val inst = (doneBytes - sampleBytes) * 1000 / dt
            speed = if (speed == 0L) inst else (speed * 6 + inst * 4) / 10
            sampleTime = now
            sampleBytes = doneBytes
            Hub.notifyChanged()
        }
    }

    fun averageSpeed(): Long {
        val dt = SystemClock.elapsedRealtime() - sessionStart
        return if (dt > 0) (doneBytes - sessionStartBytes) * 1000 / dt else 0
    }

    fun cancel() {
        cancelled = true
        try { onCancel?.invoke() } catch (e: Exception) { }
    }
}

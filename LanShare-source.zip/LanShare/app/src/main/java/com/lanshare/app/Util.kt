package com.lanshare.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.io.File
import java.io.IOException
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale

fun Context.toast(msg: String) {
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}

object Util {
    private val badChars = Regex("[\\x00-\\x1f\"*:<>?\\\\|]")

    // ---------- network ----------

    fun broadcastAddresses(): List<InetAddress> {
        val out = ArrayList<InetAddress>()
        try {
            val ifs = NetworkInterface.getNetworkInterfaces()
            if (ifs != null) {
                for (ni in Collections.list(ifs)) {
                    if (!ni.isUp || ni.isLoopback) continue
                    for (ia in ni.interfaceAddresses) {
                        val b = ia?.broadcast
                        if (b != null) out.add(b)
                    }
                }
            }
        } catch (e: Exception) { }
        try { out.add(InetAddress.getByName("255.255.255.255")) } catch (e: Exception) { }
        return out.distinct()
    }

    fun localIps(): List<String> {
        val out = ArrayList<String>()
        try {
            val ifs = NetworkInterface.getNetworkInterfaces() ?: return out
            for (ni in Collections.list(ifs)) {
                if (!ni.isUp || ni.isLoopback) continue
                val n = ni.name ?: ""
                if (n.startsWith("rmnet") || n.startsWith("ccmni") || n.startsWith("dummy") ||
                    n.startsWith("tun") || n.startsWith("ppp")) continue
                for (a in Collections.list(ni.inetAddresses)) {
                    if (a is Inet4Address) {
                        val h = a.hostAddress
                        if (h != null) out.add(h)
                    }
                }
            }
        } catch (e: Exception) { }
        return out
    }

    // ---------- formatting ----------

    fun formatBytes(b: Long): String {
        if (b < 1024) return "$b B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var v = b / 1024.0
        var i = 0
        while (v >= 1024 && i < units.size - 1) {
            v /= 1024
            i++
        }
        return String.format(Locale.US, if (v >= 100) "%.0f %s" else "%.1f %s", v, units[i])
    }

    fun formatSpeed(bps: Long): String = formatBytes(bps) + "/s"

    fun formatEta(sec: Long): String = when {
        sec < 60 -> "${sec}s"
        sec < 3600 -> "${sec / 60}m ${sec % 60}s"
        else -> "${sec / 3600}h ${(sec % 3600) / 60}m"
    }

    fun formatTime(ms: Long): String =
        SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(ms))

    // ---------- files ----------

    /** Make a path safe: no "..", no absolute paths, no illegal characters. */
    fun safeRelPath(p: String): String {
        val parts = p.replace('\\', '/').split('/')
            .map { it.trim() }
            .filter { it.isNotEmpty() && it != "." && it != ".." }
            .map { it.replace(badChars, "_") }
        return if (parts.isEmpty()) "file" else parts.joinToString("/")
    }

    /** "photo.jpg" -> "photo (1).jpg", "photo (2).jpg"… */
    fun uniqueFile(f: File): File {
        val parent = f.parentFile
        val name = f.name
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        return generateSequence(1) { it + 1 }
            .map { File(parent, "$base ($it)$ext") }
            .first { !it.exists() }
    }

    fun hasStorageAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED

    fun requestStorageAccess(a: Activity, legacy: () -> Unit) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                a.startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${a.packageName}"))
                )
            } catch (e: Exception) {
                try { a.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) } catch (e2: Exception) { }
            }
        } else {
            legacy()
        }
    }

    /** Convert a folder chosen in the system picker into a normal file path. */
    @Suppress("DEPRECATION")
    fun treeUriToPath(uri: Uri): String? = try {
        val docId = DocumentsContract.getTreeDocumentId(uri)
        when {
            docId.startsWith("raw:") -> docId.substring(4)
            uri.authority == "com.android.externalstorage.documents" -> {
                val parts = docId.split(":", limit = 2)
                val rel = parts.getOrElse(1) { "" }
                val root = if (parts[0].equals("primary", ignoreCase = true))
                    Environment.getExternalStorageDirectory().absolutePath
                else "/storage/${parts[0]}"
                if (rel.isEmpty()) root else "$root/$rel"
            }
            else -> null
        }
    } catch (e: Exception) { null }

    /** Name, size and date of a picked/shared file. */
    fun describeUri(ctx: Context, uri: Uri): SendItem {
        var name: String? = null
        var size = -1L
        var mtime = 0L
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val iName = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (iName >= 0 && !c.isNull(iName)) name = c.getString(iName)
                    val iSize = c.getColumnIndex(OpenableColumns.SIZE)
                    if (iSize >= 0 && !c.isNull(iSize)) size = c.getLong(iSize)
                    val iMod = c.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                    if (iMod >= 0 && !c.isNull(iMod)) mtime = c.getLong(iMod)
                }
            }
        } catch (e: Exception) { }
        if (uri.scheme == "file") {
            val path = uri.path
            if (path != null) {
                val f = File(path)
                if (name == null) name = f.name
                size = f.length()
                mtime = f.lastModified()
            }
        }
        if (size < 0) size = statSize(ctx, uri)
        val finalName = name ?: (uri.lastPathSegment?.substringAfterLast('/') ?: "file")
        return SendItem(uri, safeRelPath(finalName).replace('/', '_'), size, mtime)
    }

    private fun statSize(ctx: Context, uri: Uri): Long = try {
        ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
    } catch (e: Exception) { -1L }

    /** Files whose size the source app doesn't report are copied to cache first. */
    fun ensureSized(ctx: Context, items: List<SendItem>): List<SendItem> = items.map { item ->
        if (item.size >= 0) item
        else {
            val dir = File(ctx.cacheDir, "share/${System.nanoTime()}")
            dir.mkdirs()
            val f = File(dir, item.relPath.substringAfterLast('/'))
            val ins = ctx.contentResolver.openInputStream(item.uri) ?: throw IOException("Cannot read ${item.relPath}")
            ins.use { input -> f.outputStream().use { output -> input.copyTo(output, Proto.BUF) } }
            SendItem(Uri.fromFile(f), item.relPath, f.length(), if (item.mtime > 0) item.mtime else f.lastModified())
        }
    }

    /** All files inside a normal folder (in-app folder picker; needs file access). */
    fun collectDir(dir: File): List<SendItem> {
        val root = dir.name.ifEmpty { "Folder" }
        return dir.walkTopDown()
            .filter { it.isFile }
            .map { f ->
                val rel = root + "/" + f.relativeTo(dir).path.replace(File.separatorChar, '/')
                SendItem(Uri.fromFile(f), rel, f.length(), f.lastModified())
            }
            .toList()
    }

    /** Android allows ~500 remembered file permissions; drop old ones we no longer need. */
    fun trimUriGrants(ctx: Context) {
        try {
            val perms = ctx.contentResolver.persistedUriPermissions
            if (perms.size < 300) return
            val keep = Store.historyList().flatMap { it.items }.map { it.uri.toString() }.toSet()
            perms.sortedBy { it.persistedTime }.take(perms.size - 200).forEach { p ->
                if (p.uri.toString() !in keep) {
                    try {
                        ctx.contentResolver.releasePersistableUriPermission(p.uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } catch (e: Exception) { }
                }
            }
        } catch (e: Exception) { }
    }

    /** Walk a folder chosen in the system picker. Returns (folder name, files with relative paths). */
    fun collectTree(ctx: Context, tree: Uri): Pair<String, List<SendItem>> {
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        var rootName = "Folder"
        try {
            ctx.contentResolver.query(
                DocumentsContract.buildDocumentUriUsingTree(tree, rootId),
                arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null
            )?.use { c -> if (c.moveToFirst() && !c.isNull(0)) rootName = c.getString(0) }
        } catch (e: Exception) { }
        rootName = safeRelPath(rootName).replace('/', '_')
        val out = ArrayList<SendItem>()
        walk(ctx, tree, rootId, rootName, out)
        return Pair(rootName, out)
    }

    private fun walk(ctx: Context, tree: Uri, docId: String, prefix: String, out: MutableList<SendItem>) {
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        val dirs = ArrayList<Pair<String, String>>()
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                val path = prefix + "/" + name.replace('/', '_')
                if (c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR) {
                    dirs.add(Pair(id, path))
                } else {
                    out.add(
                        SendItem(
                            DocumentsContract.buildDocumentUriUsingTree(tree, id),
                            path,
                            if (c.isNull(3)) -1L else c.getLong(3),
                            if (c.isNull(4)) 0L else c.getLong(4)
                        )
                    )
                }
            }
        }
        for (d in dirs) walk(ctx, tree, d.first, d.second, out)
    }
}

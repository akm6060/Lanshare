package com.lanshare.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.atomic.AtomicInteger

object Notif {
    const val CH_SERVICE = "service"
    const val CH_EVENTS = "events"
    const val CH_PAIR = "pair"
    const val ID_SERVICE = 1
    const val ID_PAIR = 2
    private val counter = AtomicInteger(100)

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "Ready to receive", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_EVENTS, "Transfers", NotificationManager.IMPORTANCE_DEFAULT)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_PAIR, "Pairing requests", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun canPost(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    private fun post(ctx: Context, id: Int, n: Notification) {
        if (!canPost(ctx)) return
        try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (e: SecurityException) { }
    }

    fun event(ctx: Context, title: String, text: String) {
        val n = NotificationCompat.Builder(ctx, CH_EVENTS)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .build()
        post(ctx, counter.incrementAndGet(), n)
    }

    fun pairRequest(ctx: Context, name: String, code: String) {
        val n = NotificationCompat.Builder(ctx, CH_PAIR)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Pairing request from $name")
            .setContentText("Code $code — tap to accept or reject")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .build()
        post(ctx, ID_PAIR, n)
    }

    fun cancelPair(ctx: Context) {
        try { NotificationManagerCompat.from(ctx).cancel(ID_PAIR) } catch (e: Exception) { }
    }

    fun service(ctx: Context, text: String, progress: Int = -1): Notification {
        val b = NotificationCompat.Builder(ctx, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("LanShare")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(ctx))
        if (progress >= 0) b.setProgress(100, progress, false)
        return b.build()
    }

    fun updateService(ctx: Context, n: Notification) = post(ctx, ID_SERVICE, n)
}

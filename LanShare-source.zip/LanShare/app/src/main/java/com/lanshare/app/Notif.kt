package com.lanshare.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.atomic.AtomicInteger

object Notif {
    const val CH_SERVICE = "service"
    const val CH_EVENTS = "events_quiet" // silent: LanShare plays its own sound (see Sound.kt)
    const val ID_SERVICE = 1
    private val counter = AtomicInteger(100)

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        try {
            nm.deleteNotificationChannel("events")
            nm.deleteNotificationChannel("pair")
        } catch (e: Exception) { }
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "Ready to receive", NotificationManager.IMPORTANCE_LOW)
        )
        val ev = NotificationChannel(CH_EVENTS, "Transfers", NotificationManager.IMPORTANCE_DEFAULT)
        ev.setSound(null, null)
        ev.enableVibration(false)
        nm.createNotificationChannel(ev)
    }

    fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun canPost(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    private fun post(ctx: Context, id: Int, n: Notification) {
        if (!canPost(ctx)) return
        try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (e: SecurityException) { }
    }

    fun event(ctx: Context, title: String, text: String) {
        val n = NotificationCompat.Builder(ctx, CH_EVENTS)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .build()
        post(ctx, counter.incrementAndGet(), n)
    }

    fun service(ctx: Context, text: String, progress: Int = -1): Notification {
        val b = NotificationCompat.Builder(ctx, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("LanShare")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(ctx))
        if (progress >= 0) b.setProgress(100, progress, false)
        return b.build()
    }

    fun updateService(ctx: Context, n: Notification) = post(ctx, ID_SERVICE, n)
}

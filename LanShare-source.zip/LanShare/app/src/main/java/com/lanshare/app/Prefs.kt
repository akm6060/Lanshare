package com.lanshare.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Environment
import android.provider.Settings
import java.io.File
import java.util.UUID

object Prefs {
    const val DUP_OVERWRITE = 0
    const val DUP_KEEP_BOTH = 1
    const val DUP_SKIP = 2

    private fun sp(c: Context): SharedPreferences =
        c.getSharedPreferences("lanshare", Context.MODE_PRIVATE)

    @Synchronized
    fun deviceId(c: Context): String {
        val p = sp(c)
        val existing = p.getString("device_id", null)
        if (existing != null) return existing
        val id = UUID.randomUUID().toString()
        p.edit().putString("device_id", id).apply()
        return id
    }

    fun deviceName(c: Context): String {
        val saved = sp(c).getString("device_name", null)
        if (!saved.isNullOrBlank()) return saved
        val sys = try {
            Settings.Global.getString(c.contentResolver, Settings.Global.DEVICE_NAME)
        } catch (e: Exception) { null }
        return if (!sys.isNullOrBlank()) sys else "${Build.MANUFACTURER} ${Build.MODEL}".trim()
    }

    fun setDeviceName(c: Context, v: String) {
        sp(c).edit().putString("device_name", v.trim()).apply()
    }

    @Suppress("DEPRECATION")
    fun receiveDir(c: Context): File {
        val saved = sp(c).getString("receive_dir", null)
        return if (saved != null) File(saved)
        else File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LanShare")
    }

    fun setReceiveDir(c: Context, path: String?) {
        val e = sp(c).edit()
        if (path == null) e.remove("receive_dir") else e.putString("receive_dir", path)
        e.apply()
    }

    fun duplicatePolicy(c: Context): Int = sp(c).getInt("dup_policy", DUP_OVERWRITE)

    fun setDuplicatePolicy(c: Context, v: Int) {
        sp(c).edit().putInt("dup_policy", v).apply()
    }

    fun soundOnReceive(c: Context): Boolean = sp(c).getBoolean("sound_on", true)

    fun setSoundOnReceive(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("sound_on", v).apply()
    }

    /** null = phone's default notification sound, "" = no sound, else a sound Uri. */
    fun soundUri(c: Context): String? = sp(c).getString("sound_uri", null)

    fun setSoundUri(c: Context, v: String) {
        sp(c).edit().putString("sound_uri", v).apply()
    }

    /** Devices ticked on the home screen. null = never changed (all devices). */
    fun selectedTargets(c: Context): Set<String>? {
        val p = sp(c)
        if (!p.contains("targets")) return null
        return p.getStringSet("targets", null)?.toSet() ?: emptySet()
    }

    fun setSelectedTargets(c: Context, ids: Set<String>) {
        sp(c).edit().putStringSet("targets", HashSet(ids)).apply()
    }

    fun lastFolder(c: Context): String? = sp(c).getString("last_folder", null)

    fun setLastFolder(c: Context, path: String) {
        sp(c).edit().putString("last_folder", path).apply()
    }

    /** Keep CPU + Wi-Fi awake so the device stays visible with the screen off. */
    fun keepAwake(c: Context): Boolean = sp(c).getBoolean("keep_awake", true)

    fun setKeepAwake(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("keep_awake", v).apply()
    }

    fun startOnBoot(c: Context): Boolean = sp(c).getBoolean("start_on_boot", true)

    fun setStartOnBoot(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("start_on_boot", v).apply()
    }

    fun copyTextToClipboard(c: Context): Boolean = sp(c).getBoolean("copy_text", true)

    fun setCopyTextToClipboard(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("copy_text", v).apply()
    }

    // ---------- auto-send & daily move (see AutoSend.kt) ----------

    fun autoSendEnabled(c: Context): Boolean = sp(c).getBoolean("auto_on", false)

    fun setAutoSendEnabled(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("auto_on", v).apply()
    }

    fun autoFolders(c: Context): Set<String> = sp(c).getStringSet("auto_folders", null)?.toSet() ?: emptySet()

    fun setAutoFolders(c: Context, v: Set<String>) {
        sp(c).edit().putStringSet("auto_folders", HashSet(v)).apply()
    }

    fun autoTargets(c: Context): Set<String> = sp(c).getStringSet("auto_targets", null)?.toSet() ?: emptySet()

    fun setAutoTargets(c: Context, v: Set<String>) {
        sp(c).edit().putStringSet("auto_targets", HashSet(v)).apply()
    }

    /** Sub-folder inside the receiving device's receive folder ("" = directly in it). */
    fun autoStoreSubfolder(c: Context): String = sp(c).getString("auto_sub", "Prescriptions") ?: ""

    fun setAutoStoreSubfolder(c: Context, v: String) {
        sp(c).edit().putString("auto_sub", v).apply()
    }

    /** File types to send / move, e.g. "html" or "html, pdf". Empty = all files. */
    fun autoTypes(c: Context): String = sp(c).getString("auto_types", "html") ?: ""

    fun setAutoTypes(c: Context, v: String) {
        sp(c).edit().putString("auto_types", v).apply()
    }

    /** Seconds a file must stay unchanged before it is sent. */
    fun autoDelaySec(c: Context): Int = sp(c).getInt("auto_delay", 3).coerceIn(1, 600)

    fun setAutoDelaySec(c: Context, v: Int) {
        sp(c).edit().putInt("auto_delay", v.coerceIn(1, 600)).apply()
    }

    /** Auto-send was switched on: files already in the folders count as sent. */
    fun requestAutoRebaseline(c: Context) {
        sp(c).edit().putBoolean("auto_rebase", true).apply()
    }

    @Synchronized
    fun takeAutoRebaseline(c: Context): Boolean {
        val p = sp(c)
        if (!p.getBoolean("auto_rebase", false)) return false
        p.edit().putBoolean("auto_rebase", false).apply()
        return true
    }

    fun moveEnabled(c: Context): Boolean = sp(c).getBoolean("move_on", false)

    fun setMoveEnabled(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("move_on", v).apply()
    }

    fun moveFrom(c: Context): String? = sp(c).getString("move_from", null)

    fun setMoveFrom(c: Context, v: String?) {
        val e = sp(c).edit()
        if (v == null) e.remove("move_from") else e.putString("move_from", v)
        e.apply()
    }

    fun moveTo(c: Context): String? = sp(c).getString("move_to", null)

    fun setMoveTo(c: Context, v: String?) {
        val e = sp(c).edit()
        if (v == null) e.remove("move_to") else e.putString("move_to", v)
        e.apply()
    }
}

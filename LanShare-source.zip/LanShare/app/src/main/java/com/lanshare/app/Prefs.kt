package com.lanshare.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Environment
import android.provider.Settings
import java.io.File
import java.util.UUID

object Prefs {
    const val DUP_OVERWRITE = 0
    const val DUP_KEEP_BOTH = 1
    const val DUP_SKIP = 2

    private fun sp(c: Context): SharedPreferences =
        c.getSharedPreferences("lanshare", Context.MODE_PRIVATE)

    @Synchronized
    fun deviceId(c: Context): String {
        val p = sp(c)
        val existing = p.getString("device_id", null)
        if (existing != null) return existing
        val id = UUID.randomUUID().toString()
        p.edit().putString("device_id", id).apply()
        return id
    }

    fun deviceName(c: Context): String {
        val saved = sp(c).getString("device_name", null)
        if (!saved.isNullOrBlank()) return saved
        val sys = try {
            Settings.Global.getString(c.contentResolver, Settings.Global.DEVICE_NAME)
        } catch (e: Exception) { null }
        return if (!sys.isNullOrBlank()) sys else "${Build.MANUFACTURER} ${Build.MODEL}".trim()
    }

    fun setDeviceName(c: Context, v: String) {
        sp(c).edit().putString("device_name", v.trim()).apply()
    }

    @Suppress("DEPRECATION")
    fun receiveDir(c: Context): File {
        val saved = sp(c).getString("receive_dir", null)
        return if (saved != null) File(saved)
        else File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LanShare")
    }

    fun setReceiveDir(c: Context, path: String?) {
        val e = sp(c).edit()
        if (path == null) e.remove("receive_dir") else e.putString("receive_dir", path)
        e.apply()
    }

    fun duplicatePolicy(c: Context): Int = sp(c).getInt("dup_policy", DUP_OVERWRITE)

    fun setDuplicatePolicy(c: Context, v: Int) {
        sp(c).edit().putInt("dup_policy", v).apply()
    }

    fun soundOnReceive(c: Context): Boolean = sp(c).getBoolean("sound_on", true)

    fun setSoundOnReceive(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("sound_on", v).apply()
    }

    /** null = phone's default notification sound, "" = no sound, else a sound Uri. */
    fun soundUri(c: Context): String? = sp(c).getString("sound_uri", null)

    fun setSoundUri(c: Context, v: String) {
        sp(c).edit().putString("sound_uri", v).apply()
    }

    /** Devices ticked on the home screen. null = never changed (all devices). */
    fun selectedTargets(c: Context): Set<String>? {
        val p = sp(c)
        if (!p.contains("targets")) return null
        return p.getStringSet("targets", null)?.toSet() ?: emptySet()
    }

    fun setSelectedTargets(c: Context, ids: Set<String>) {
        sp(c).edit().putStringSet("targets", HashSet(ids)).apply()
    }

    fun lastFolder(c: Context): String? = sp(c).getString("last_folder", null)

    fun setLastFolder(c: Context, path: String) {
        sp(c).edit().putString("last_folder", path).apply()
    }

    fun copyTextToClipboard(c: Context): Boolean = sp(c).getBoolean("copy_text", true)

    fun setCopyTextToClipboard(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("copy_text", v).apply()
    }
}

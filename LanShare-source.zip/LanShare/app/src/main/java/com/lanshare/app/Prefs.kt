package com.lanshare.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Environment
import android.provider.Settings
import java.io.File
import java.util.UUID

object Prefs {
    const val DUP_OVERWRITE = 0
    const val DUP_KEEP_BOTH = 1
    const val DUP_SKIP = 2

    private fun sp(c: Context): SharedPreferences =
        c.getSharedPreferences("lanshare", Context.MODE_PRIVATE)

    @Synchronized
    fun deviceId(c: Context): String {
        val p = sp(c)
        val existing = p.getString("device_id", null)
        if (existing != null) return existing
        val id = UUID.randomUUID().toString()
        p.edit().putString("device_id", id).apply()
        return id
    }

    fun deviceName(c: Context): String {
        val saved = sp(c).getString("device_name", null)
        if (!saved.isNullOrBlank()) return saved
        val sys = try {
            Settings.Global.getString(c.contentResolver, Settings.Global.DEVICE_NAME)
        } catch (e: Exception) { null }
        return if (!sys.isNullOrBlank()) sys else "${Build.MANUFACTURER} ${Build.MODEL}".trim()
    }

    fun setDeviceName(c: Context, v: String) {
        sp(c).edit().putString("device_name", v.trim()).apply()
    }

    @Suppress("DEPRECATION")
    fun receiveDir(c: Context): File {
        val saved = sp(c).getString("receive_dir", null)
        return if (saved != null) File(saved)
        else File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LanShare")
    }

    fun setReceiveDir(c: Context, path: String?) {
        val e = sp(c).edit()
        if (path == null) e.remove("receive_dir") else e.putString("receive_dir", path)
        e.apply()
    }

    fun duplicatePolicy(c: Context): Int = sp(c).getInt("dup_policy", DUP_OVERWRITE)

    fun setDuplicatePolicy(c: Context, v: Int) {
        sp(c).edit().putInt("dup_policy", v).apply()
    }

    fun copyTextToClipboard(c: Context): Boolean = sp(c).getBoolean("copy_text", true)

    fun setCopyTextToClipboard(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("copy_text", v).apply()
    }
}

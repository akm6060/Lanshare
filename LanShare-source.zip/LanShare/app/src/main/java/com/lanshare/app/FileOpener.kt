package com.lanshare.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.StrictMode
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File
import java.util.Locale

/** Opens a file remembered in History with the right app (e.g. a prescription in Write). */
object FileOpener {
    /** Stylus Labs Write. */
    private const val WRITE_PKG = "com.styluslabs.writeqt"

    /** What a remembered location points to right now. */
    class Target(val name: String, val file: File?, val uri: Uri?) {
        val found: Boolean get() = file != null || uri != null
    }

    /**
     * [ref] is a path or a content link. A path that no longer exists (for example a prescription
     * moved to the backup folder at night) is looked up by name in the auto-send / move folders.
     */
    fun resolve(a: Activity, ref: String): Target {
        if (ref.startsWith("content://")) {
            val uri = Uri.parse(ref)
            val local = Util.localPathOf(uri)
            if (local != null) return resolve(a, local)
            val name = Uri.decode(uri.lastPathSegment ?: "file").substringAfterLast('/')
            return Target(name, null, uri)
        }
        val path = if (ref.startsWith("file://")) Uri.parse(ref).path ?: ref else ref
        val f = File(path)
        if (f.isFile) return Target(f.name, f, null)
        return Target(f.name, AutoSend.findByName(a, f.name), null)
    }

    fun open(a: Activity, ref: String) {
        val t = resolve(a, ref)
        if (!t.found) {
            a.toast("“${t.name}” is no longer on this device (deleted, renamed or moved)")
            return
        }
        val file = t.file
        val lower = t.name.lowercase(Locale.ROOT)
        if (file != null && (lower.endsWith(".html") || lower.endsWith(".htm")) && openInWrite(a, file)) return
        openWithLink(a, t, chooser = false)
    }

    /** Long-press → "Open with…": lets you pick any app (e.g. a browser) for this file. */
    fun openWith(a: Activity, ref: String) {
        val t = resolve(a, ref)
        if (!t.found) {
            a.toast("“${t.name}” is no longer on this device (deleted, renamed or moved)")
            return
        }
        openWithLink(a, t, chooser = true)
    }

    /**
     * Write (2017) only understands real file paths, not the content links modern Android uses
     * between apps ("Error opening document"). Android blocks file paths by default; that check is
     * switched off for this one launch only. Write then edits the real file, so auto-send notices.
     */
    private fun openInWrite(a: Activity, f: File): Boolean {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(Uri.fromFile(f), "text/html")
            .setPackage(WRITE_PKG)
        val old = StrictMode.getVmPolicy()
        return try {
            StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder().build())
            a.startActivity(i)
            true
        } catch (e: Exception) {
            false // Write not installed (or refused): fall back to the normal way
        } finally {
            StrictMode.setVmPolicy(old)
        }
    }

    private fun openWithLink(a: Activity, t: Target, chooser: Boolean) {
        val file = t.file
        val uri = if (file != null) contentUriFor(a, file) else t.uri
        if (uri == null) {
            a.toast("Can't open “${t.name}” from this folder")
            return
        }
        val ext = t.name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        try {
            a.startActivity(if (chooser) Intent.createChooser(i, "Open “${t.name}” with") else i)
        } catch (e: ActivityNotFoundException) {
            a.toast(if (ext.isEmpty()) "No app can open this file" else "No app on this device can open .$ext files")
        } catch (e: SecurityException) {
            a.toast("LanShare can no longer open “${t.name}”. Open it from its own app.")
        } catch (e: Exception) {
            a.toast("Can't open “${t.name}”: ${e.message}")
        }
    }

    private fun contentUriFor(a: Activity, f: File): Uri? = try {
        FileProvider.getUriForFile(a, a.packageName + ".files", f)
    } catch (e: Exception) {
        null
    }
}

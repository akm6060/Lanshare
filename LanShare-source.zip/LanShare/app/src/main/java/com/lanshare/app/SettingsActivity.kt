package com.lanshare.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.google.android.material.appbar.MaterialToolbar
import java.io.File

class SettingsActivity : AppCompatActivity() {
    private lateinit var txtFolder: TextView
    private lateinit var txtStorage: TextView

    private val pickDir =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) onDirPicked(uri) }
    private val askLegacy =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { render() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        val tb = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(tb)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        tb.setNavigationOnClickListener { finish() }

        txtFolder = findViewById(R.id.txtFolder)
        txtStorage = findViewById(R.id.txtStorage)

        val edit = findViewById<EditText>(R.id.editName)
        edit.setText(Prefs.deviceName(this))
        findViewById<Button>(R.id.btnSaveName).setOnClickListener {
            val n = edit.text.toString().trim()
            if (n.isNotEmpty()) {
                Prefs.setDeviceName(this, n)
                Discovery.current?.announceAsync()
                toast("Name saved")
            }
        }

        findViewById<Button>(R.id.btnFolder).setOnClickListener { pickDir.launch(null) }
        findViewById<Button>(R.id.btnFolderReset).setOnClickListener {
            Prefs.setReceiveDir(this, null)
            render()
        }

        val group = findViewById<RadioGroup>(R.id.dupGroup)
        group.check(
            when (Prefs.duplicatePolicy(this)) {
                Prefs.DUP_KEEP_BOTH -> R.id.radioKeepBoth
                Prefs.DUP_SKIP -> R.id.radioSkip
                else -> R.id.radioOverwrite
            }
        )
        group.setOnCheckedChangeListener { _, checkedId ->
            val v = when (checkedId) {
                R.id.radioKeepBoth -> Prefs.DUP_KEEP_BOTH
                R.id.radioSkip -> Prefs.DUP_SKIP
                else -> Prefs.DUP_OVERWRITE
            }
            Prefs.setDuplicatePolicy(this, v)
        }

        val sw = findViewById<SwitchCompat>(R.id.switchClipboard)
        sw.isChecked = Prefs.copyTextToClipboard(this)
        sw.setOnCheckedChangeListener { _, checked -> Prefs.setCopyTextToClipboard(this, checked) }

        findViewById<Button>(R.id.btnStorage).setOnClickListener {
            Util.requestStorageAccess(this) { askLegacy.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE) }
        }
        findViewById<Button>(R.id.btnBattery).setOnClickListener { requestBattery() }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            TransferService.stop(this)
            finishAffinity()
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        txtFolder.text = Prefs.receiveDir(this).absolutePath
        val pm = getSystemService(PowerManager::class.java)
        val battery = pm?.isIgnoringBatteryOptimizations(packageName) == true
        txtStorage.text = (if (Util.hasStorageAccess(this)) "✓ File access allowed" else "✗ File access not allowed") +
            "\n" + (if (battery) "✓ Background running allowed" else "✗ Battery saver may stop LanShare in background")
    }

    private fun onDirPicked(uri: Uri) {
        val path = Util.treeUriToPath(uri)
        if (path == null) {
            toast("Please choose a folder on the phone's storage")
            return
        }
        val f = File(path)
        f.mkdirs()
        if (!f.isDirectory) {
            toast("Can't use that folder. Allow file access first.")
            return
        }
        Prefs.setReceiveDir(this, f.absolutePath)
        render()
        toast("Incoming files will be saved to ${f.absolutePath}")
    }

    @SuppressLint("BatteryLife")
    private fun requestBattery() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm != null && pm.isIgnoringBatteryOptimizations(packageName)) {
            toast("Already allowed")
            return
        }
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) { }
        }
    }
}

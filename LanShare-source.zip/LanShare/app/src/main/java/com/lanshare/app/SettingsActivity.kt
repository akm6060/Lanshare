package com.lanshare.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.IntentCompat
import com.google.android.material.appbar.MaterialToolbar
import java.io.File

class SettingsActivity : AppCompatActivity() {
    private lateinit var txtFolder: TextView
    private lateinit var txtStorage: TextView
    private lateinit var txtSound: TextView
    private lateinit var txtDeviceInfo: TextView

    private val pickDir =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri -> if (uri != null) onDirPicked(uri) }
    private val pickSound =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            if (res.resultCode == RESULT_OK) {
                val data = res.data
                val uri = if (data != null)
                    IntentCompat.getParcelableExtra(data, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
                else null
                Prefs.setSoundUri(this, uri?.toString() ?: "")
                render()
            }
        }
    private val askLegacy =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { render() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        val tb = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(tb)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        tb.setNavigationOnClickListener { finish() }

        txtFolder = findViewById(R.id.txtFolder)
        txtStorage = findViewById(R.id.txtStorage)
        txtSound = findViewById(R.id.txtSound)
        txtDeviceInfo = findViewById(R.id.txtDeviceInfo)

        findViewById<Button>(R.id.btnAutoSend).setOnClickListener {
            startActivity(Intent(this, AutoSendActivity::class.java))
        }

        val swSound = findViewById<SwitchCompat>(R.id.switchSound)
        swSound.isChecked = Prefs.soundOnReceive(this)
        swSound.setOnCheckedChangeListener { _, checked -> Prefs.setSoundOnReceive(this, checked) }
        findViewById<Button>(R.id.btnSound).setOnClickListener {
            val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL)
                .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Sound for received files")
                .putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Sound.currentUri(this))
            try {
                pickSound.launch(i)
            } catch (e: Exception) {
                toast("No sound picker on this phone")
            }
        }
        findViewById<Button>(R.id.btnTestSound).setOnClickListener { Sound.play(this, force = true) }

        val edit = findViewById<EditText>(R.id.editName)
        edit.setText(Prefs.deviceName(this))
        findViewById<Button>(R.id.btnSaveName).setOnClickListener {
            val n = edit.text.toString().trim()
            if (n.isNotEmpty()) {
                Prefs.setDeviceName(this, n)
                Discovery.current?.announceAsync()
                toast("Name saved")
            }
        }

        findViewById<Button>(R.id.btnFolder).setOnClickListener { pickDir.launch(null) }
        findViewById<Button>(R.id.btnFolderReset).setOnClickListener {
            Prefs.setReceiveDir(this, null)
            render()
        }

        val group = findViewById<RadioGroup>(R.id.dupGroup)
        group.check(
            when (Prefs.duplicatePolicy(this)) {
                Prefs.DUP_KEEP_BOTH -> R.id.radioKeepBoth
                Prefs.DUP_SKIP -> R.id.radioSkip
                else -> R.id.radioOverwrite
            }
        )
        group.setOnCheckedChangeListener { _, checkedId ->
            val v = when (checkedId) {
                R.id.radioKeepBoth -> Prefs.DUP_KEEP_BOTH
                R.id.radioSkip -> Prefs.DUP_SKIP
                else -> Prefs.DUP_OVERWRITE
            }
            Prefs.setDuplicatePolicy(this, v)
        }

        val sw = findViewById<SwitchCompat>(R.id.switchClipboard)
        sw.isChecked = Prefs.copyTextToClipboard(this)
        sw.setOnCheckedChangeListener { _, checked -> Prefs.setCopyTextToClipboard(this, checked) }

        findViewById<Button>(R.id.btnStorage).setOnClickListener {
            Util.requestStorageAccess(this) { askLegacy.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE) }
        }
        findViewById<Button>(R.id.btnBattery).setOnClickListener { requestBattery() }

        val swAwake = findViewById<SwitchCompat>(R.id.switchKeepAwake)
        swAwake.isChecked = Prefs.keepAwake(this)
        swAwake.setOnCheckedChangeListener { _, checked ->
            Prefs.setKeepAwake(this, checked)
            if (TransferService.running) Work.setStandby(checked)
        }
        val swBoot = findViewById<SwitchCompat>(R.id.switchBoot)
        swBoot.isChecked = Prefs.startOnBoot(this)
        swBoot.setOnCheckedChangeListener { _, checked -> Prefs.setStartOnBoot(this, checked) }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            TransferService.stop(this)
            finishAffinity()
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        txtFolder.text = Prefs.receiveDir(this).absolutePath
        val ips = Util.localIps()
        txtDeviceInfo.text = (if (ips.isEmpty()) "Not connected to Wi-Fi" else "IP address: " + ips.joinToString(", ")) +
            "\nLanShare " + appVersion()
        txtSound.text = "Sound: " + Sound.title(this)
        val battery = Util.isIgnoringBattery(this)
        txtStorage.text = (if (Util.hasStorageAccess(this)) "✓ File access allowed" else "✗ File access not allowed") +
            "\n" + (if (battery) "✓ Background running allowed" else "✗ Battery saver may stop LanShare in background")
    }

    private fun onDirPicked(uri: Uri) {
        val path = Util.treeUriToPath(uri)
        if (path == null) {
            toast("Please choose a folder on the phone's storage")
            return
        }
        val f = File(path)
        f.mkdirs()
        if (!f.isDirectory) {
            toast("Can't use that folder. Allow file access first.")
            return
        }
        Prefs.setReceiveDir(this, f.absolutePath)
        render()
        toast("Incoming files will be saved to ${f.absolutePath}")
    }

    private fun appVersion(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: ""
    } catch (e: Exception) { "" }

    private fun requestBattery() {
        if (Util.isIgnoringBattery(this)) {
            toast("Already allowed")
            return
        }
        Util.requestBatteryExemption(this)
    }
}

package com.lanshare.app

import android.content.Context
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.SystemClock

/** Plays a sound when files or text arrive — works with the app in the background. */
object Sound {
    private var current: Ringtone? = null
    private var last = 0L

    fun currentUri(ctx: Context): Uri? {
        val s = Prefs.soundUri(ctx)
        return when {
            s == null -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            s.isEmpty() -> null
            else -> Uri.parse(s)
        }
    }

    fun title(ctx: Context): String {
        val u = currentUri(ctx) ?: return "None"
        return try {
            RingtoneManager.getRingtone(ctx, u)?.getTitle(ctx) ?: "Default"
        } catch (e: Exception) { "Default" }
    }

    @Synchronized
    fun play(ctx: Context, force: Boolean = false) {
        if (!force && !Prefs.soundOnReceive(ctx)) return
        val now = SystemClock.elapsedRealtime()
        if (!force && now - last < 1500) return // several files finishing together = one sound
        last = now
        val app = ctx.applicationContext
        Hub.main.post { playNow(app) }
    }

    private fun playNow(ctx: Context) {
        try {
            current?.stop()
            val uri = currentUri(ctx) ?: return
            val r = RingtoneManager.getRingtone(ctx, uri) ?: return
            r.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            r.play()
            current = r
            // if a long ringtone was chosen, cut it after 6 seconds
            Hub.main.postDelayed({ if (current === r) r.stop() }, 6000)
        } catch (e: Exception) { }
    }
}

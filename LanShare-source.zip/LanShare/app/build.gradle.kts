plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.lanshare.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.lanshare.app"
        minSdk = 23
        targetSdk = 34
        versionCode = 12
        versionName = "1.3.3"
    }

    // Fixed key so every new build installs as an UPDATE over the old one.
    signingConfigs {
        create("shared") {
            storeFile = file("lanshare.keystore")
            storePassword = "lanshare"
            keyAlias = "lanshare"
            keyPassword = "lanshare"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("shared")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("shared")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}
